(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[2144],{2898:function(e,t,r){"use strict";r.d(t,{Z:function(){return s}});var a=r(2265),o={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase().trim(),s=(e,t)=>{let r=(0,a.forwardRef)(({color:r="currentColor",size:s=24,strokeWidth:n=2,absoluteStrokeWidth:l,className:c="",children:d,...u},p)=>(0,a.createElement)("svg",{ref:p,...o,width:s,height:s,stroke:r,strokeWidth:l?24*Number(n)/Number(s):n,className:["lucide",`lucide-${i(e)}`,c].join(" "),...u},[...t.map(([e,t])=>(0,a.createElement)(e,t)),...Array.isArray(d)?d:[d]]));return r.displayName=`${e}`,r}},3067:function(e,t,r){"use strict";r.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(2898).Z)("ArrowLeft",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]])},8222:function(e,t,r){"use strict";var a=r(7541);let o=[{id:"seating",name:"Seating",slug:"seating"},{id:"objects",name:"Objects",slug:"objects"},{id:"lighting",name:"Lighting",slug:"lighting"}];function i(e){return Promise.resolve({data:e})}t.Z={get:e=>{if(e.startsWith("/products?featured")||e.startsWith("/products?"))return i({products:a.n6,pagination:{total:a.n6.length}});if(e.startsWith("/products/")){let t=e.replace("/products/","").split("?")[0],r=a.n6.find(e=>e.slug===t);return r?i(r):Promise.reject(Error("Not found"))}return"/categories"===e?i(o):"/collections"===e?i(a.jn):"/orders"===e||e.startsWith("/users/wishlist")||e.startsWith("/users/addresses")?i([]):i({})},post:(e,t)=>"/auth/login"===e?i({user:{id:"mock-user",name:"Guest User",email:(null==t?void 0:t.email)||"user@jodour.com",role:"USER"},accessToken:"mock-token"}):"/auth/register"===e?i({user:{id:"mock-user",name:(null==t?void 0:t.name)||"Guest User",email:(null==t?void 0:t.email)||"user@jodour.com",role:"USER"},accessToken:"mock-token"}):"/auth/logout"===e?i({}):"/auth/refresh"===e?Promise.reject(Error("No refresh")):"/messages"===e||"/newsletter"===e?i({success:!0}):"/users/addresses"===e?i({id:"mock-address"}):"/orders"===e?i({id:"mock-order",orderNumber:"JOD-"+Math.floor(9e4*Math.random()+1e4)}):e.startsWith("/payments/")?i({url:"/checkout/success"}):e.startsWith("/users/wishlist/")?i({added:!0}):i({}),put:(e,t)=>i({}),patch:(e,t)=>i({}),delete:e=>i({}),defaults:{headers:{common:{}}},interceptors:{request:{use:()=>{}},response:{use:()=>{}}}}},7541:function(e,t,r){"use strict";r.d(t,{OX:function(){return n},jn:function(){return s},n6:function(){return i}});let a="/assets/products";function o(e,t,r){return Array.from({length:t},(t,o)=>({id:"".concat(e,"-").concat(o+1),url:"".concat(a,"/").concat(e,"-").concat(o+1,".png"),alt:0===o?r:"".concat(r," view ").concat(o+1)}))}let i=[{id:"cloud",title:"Cloud",slug:"cloud",price:1890,comparePrice:2200,limited:!0,stock:12,featured:!0,description:"An sculptural office chair blending organic copper forms with textured upholstery — where Moroccan craftsmanship meets contemporary workspace design.",story:"Inspired by desert clouds and the soft curves of Atlas landscapes, Cloud reimagines the executive chair as a collectible design object.",images:[{id:"cloud-1",url:"".concat(a,"/cloud-1.png"),alt:"Cloud chair"},{id:"cloud-2",url:"".concat(a,"/cloud-2.png"),alt:"Cloud chair view 2"},{id:"cloud-4",url:"".concat(a,"/cloud-4.png"),alt:"Cloud chair view 3"},{id:"cloud-5",url:"".concat(a,"/cloud-5.png"),alt:"Cloud chair view 4"},{id:"cloud-6",url:"".concat(a,"/cloud-6.png"),alt:"Cloud chair view 5"}],category:{name:"Seating",slug:"seating"},collection:{name:"Cloud Collection",slug:"cloud"},materials:[{id:"m1",name:"Copper"},{id:"m2",name:"Wool upholstery"}],dimensions:{width:65,height:120,depth:70,weight:18,unit:"cm"},reviews:[],_count:{reviews:0},related:[]},{id:"chelal",title:"Chelal",slug:"chelal",price:450,limited:!0,stock:24,featured:!0,description:"A luxury electric kettle adorned with traditional Moroccan filigree patterns in gold and bronze — heritage reimagined for the modern kitchen.",story:"Chelal draws from the ornate metalwork of Moroccan tea culture, transforming an everyday ritual into a moment of design.",images:o("chelal",4,"Chelal kettle"),category:{name:"Objects",slug:"objects"},collection:{name:"Chelal Collection",slug:"chelal"},materials:[{id:"m3",name:"Matte ceramic"},{id:"m4",name:"Gold filigree"}],dimensions:{width:22,height:28,depth:22,weight:1.8,unit:"cm"},reviews:[],_count:{reviews:0},related:[]},{id:"manara",title:"Manara",slug:"manara",price:680,limited:!0,stock:18,featured:!0,description:"Hammered copper table lamps with patterned ceramic bases — light as sculpture, rooted in Moroccan decorative tradition.",story:"Manara, meaning lighthouse, guides the eye through concentric copper rings that diffuse warm, ambient light.",images:o("manara",5,"Manara lamp"),category:{name:"Lighting",slug:"lighting"},collection:{name:"Manara Collection",slug:"manara"},materials:[{id:"m5",name:"Hammered copper"},{id:"m6",name:"Ceramic"}],dimensions:{width:35,height:55,depth:35,weight:3.2,unit:"cm"},reviews:[],_count:{reviews:0},related:[]}],s=[{id:"cloud",name:"Cloud",slug:"cloud",description:"Sculptural seating — copper and wool in organic harmony.",image:"".concat(a,"/cloud-1.png"),featured:!0,_count:{products:1}},{id:"chelal",name:"Chelal",slug:"chelal",description:"Moroccan filigree meets modern kitchen ritual.",image:"".concat(a,"/chelal-1.png"),featured:!0,_count:{products:1}},{id:"manara",name:"Manara",slug:"manara",description:"Hammered copper lighting — light as collectible art.",image:"".concat(a,"/manara-1.png"),featured:!0,_count:{products:1}}];function n(e){let t=i.find(t=>t.slug===e);if(!t)return null;let r=i.filter(t=>t.slug!==e).map(e=>({id:e.id,title:e.title,price:e.price,slug:e.slug,images:e.images}));return{...t,related:r}}},622:function(e,t,r){"use strict";var a=r(2265),o=Symbol.for("react.element"),i=Symbol.for("react.fragment"),s=Object.prototype.hasOwnProperty,n=a.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,l={key:!0,ref:!0,__self:!0,__source:!0};function c(e,t,r){var a,i={},c=null,d=null;for(a in void 0!==r&&(c=""+r),void 0!==t.key&&(c=""+t.key),void 0!==t.ref&&(d=t.ref),t)s.call(t,a)&&!l.hasOwnProperty(a)&&(i[a]=t[a]);if(e&&e.defaultProps)for(a in t=e.defaultProps)void 0===i[a]&&(i[a]=t[a]);return{$$typeof:o,type:e,key:c,ref:d,props:i,_owner:n.current}}t.Fragment=i,t.jsx=c,t.jsxs=c},7437:function(e,t,r){"use strict";e.exports=r(622)},4033:function(e,t,r){e.exports=r(5313)},5925:function(e,t,r){"use strict";let a,o;r.r(t),r.d(t,{CheckmarkIcon:function(){return X},ErrorIcon:function(){return G},LoaderIcon:function(){return Y},ToastBar:function(){return el},ToastIcon:function(){return er},Toaster:function(){return ep},default:function(){return em},resolveValue:function(){return E},toast:function(){return W},useToaster:function(){return U},useToasterStore:function(){return T}});var i,s=r(2265);let n={data:""},l=e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||n},c=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,d=/\/\*[^]*?\*\/|  +/g,u=/\n+/g,p=(e,t)=>{let r="",a="",o="";for(let i in e){let s=e[i];"@"==i[0]?"i"==i[1]?r=i+" "+s+";":a+="f"==i[1]?p(s,i):i+"{"+p(s,"k"==i[1]?"":t)+"}":"object"==typeof s?a+=p(s,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=s&&(i="-"==i[1]?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),o+=p.p?p.p(i,s):i+":"+s+";")}return r+(t&&o?t+"{"+o+"}":o)+a},m={},f=e=>{if("object"==typeof e){let t="";for(let r in e)t+=r+f(e[r]);return t}return e},g=(e,t,r,a,o)=>{var i;let s=f(e),n=m[s]||(m[s]=(e=>{let t=0,r=11;for(;t<e.length;)r=101*r+e.charCodeAt(t++)>>>0;return"go"+r})(s));if(!m[n]){let t=s!==e?e:(e=>{let t,r,a=[{}];for(;t=c.exec(e.replace(d,""));)t[4]?a.shift():t[3]?(r=t[3].replace(u," ").trim(),a.unshift(a[0][r]=a[0][r]||{})):a[0][t[1]]=t[2].replace(u," ").trim();return a[0]})(e);m[n]=p(o?{["@keyframes "+n]:t}:t,r?"":"."+n)}let l=r&&m.g;return r&&(m.g=m[n]),i=m[n],l?t.data=t.data.replace(l,i):-1===t.data.indexOf(i)&&(t.data=a?i+t.data:t.data+i),n},h=(e,t,r)=>e.reduce((e,a,o)=>{let i=t[o];if(i&&i.call){let e=i(r),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":p(e,""):!1===e?"":e}return e+a+(null==i?"":i)},"");function y(e){let t=this||{},r=e.call?e(t.p):e;return g(r.unshift?r.raw?h(r,[].slice.call(arguments,1),t.p):r.reduce((e,r)=>Object.assign(e,r&&r.call?r(t.p):r),{}):r,l(t.target),t.g,t.o,t.k)}y.bind({g:1});let b,v,w,x=y.bind({k:1});function k(e,t){let r=this||{};return function(){let a=arguments;function o(i,s){let n=Object.assign({},i),l=n.className||o.className;r.p=Object.assign({theme:v&&v()},n),r.o=/go\d/.test(l),n.className=y.apply(r,a)+(l?" "+l:""),t&&(n.ref=s);let c=e;return e[0]&&(c=n.as||e,delete n.as),w&&c[0]&&w(n),b(c,n)}return t?t(o):o}}var C=e=>"function"==typeof e,E=(e,t)=>C(e)?e(t):e,_=(a=0,()=>(++a).toString()),j=()=>{if(void 0===o&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");o=!e||e.matches}return o},O="default",$=(e,t)=>{let{toastLimit:r}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,r)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:a}=t;return $(e,{type:e.toasts.find(e=>e.id===a.id)?1:0,toast:a});case 3:let{toastId:o}=t;return{...e,toasts:e.toasts.map(e=>e.id===o||void 0===o?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},N=[],A={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},M={},I=(e,t=O)=>{M[t]=$(M[t]||A,e),N.forEach(([e,r])=>{e===t&&r(M[t])})},D=e=>Object.keys(M).forEach(t=>I(e,t)),L=e=>Object.keys(M).find(t=>M[t].toasts.some(t=>t.id===e)),P=(e=O)=>t=>{I(t,e)},S={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},T=(e={},t=O)=>{let[r,a]=(0,s.useState)(M[t]||A),o=(0,s.useRef)(M[t]);(0,s.useEffect)(()=>(o.current!==M[t]&&a(M[t]),N.push([t,a]),()=>{let e=N.findIndex(([e])=>e===t);e>-1&&N.splice(e,1)}),[t]);let i=r.toasts.map(t=>{var r,a,o;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(r=e[t.type])?void 0:r.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(a=e[t.type])?void 0:a.duration)||(null==e?void 0:e.duration)||S[t.type],style:{...e.style,...null==(o=e[t.type])?void 0:o.style,...t.style}}});return{...r,toasts:i}},z=(e,t="blank",r)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...r,id:(null==r?void 0:r.id)||_()}),R=e=>(t,r)=>{let a=z(t,e,r);return P(a.toasterId||L(a.id))({type:2,toast:a}),a.id},W=(e,t)=>R("blank")(e,t);W.error=R("error"),W.success=R("success"),W.loading=R("loading"),W.custom=R("custom"),W.dismiss=(e,t)=>{let r={type:3,toastId:e};t?P(t)(r):D(r)},W.dismissAll=e=>W.dismiss(void 0,e),W.remove=(e,t)=>{let r={type:4,toastId:e};t?P(t)(r):D(r)},W.removeAll=e=>W.remove(void 0,e),W.promise=(e,t,r)=>{let a=W.loading(t.loading,{...r,...null==r?void 0:r.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let o=t.success?E(t.success,e):void 0;return o?W.success(o,{id:a,...r,...null==r?void 0:r.success}):W.dismiss(a),e}).catch(e=>{let o=t.error?E(t.error,e):void 0;o?W.error(o,{id:a,...r,...null==r?void 0:r.error}):W.dismiss(a)}),e};var H=1e3,U=(e,t="default")=>{let{toasts:r,pausedAt:a}=T(e,t),o=(0,s.useRef)(new Map).current,i=(0,s.useCallback)((e,t=H)=>{if(o.has(e))return;let r=setTimeout(()=>{o.delete(e),n({type:4,toastId:e})},t);o.set(e,r)},[]);(0,s.useEffect)(()=>{if(a)return;let e=Date.now(),o=r.map(r=>{if(r.duration===1/0)return;let a=(r.duration||0)+r.pauseDuration-(e-r.createdAt);if(a<0){r.visible&&W.dismiss(r.id);return}return setTimeout(()=>W.dismiss(r.id,t),a)});return()=>{o.forEach(e=>e&&clearTimeout(e))}},[r,a,t]);let n=(0,s.useCallback)(P(t),[t]),l=(0,s.useCallback)(()=>{n({type:5,time:Date.now()})},[n]),c=(0,s.useCallback)((e,t)=>{n({type:1,toast:{id:e,height:t}})},[n]),d=(0,s.useCallback)(()=>{a&&n({type:6,time:Date.now()})},[a,n]),u=(0,s.useCallback)((e,t)=>{let{reverseOrder:a=!1,gutter:o=8,defaultPosition:i}=t||{},s=r.filter(t=>(t.position||i)===(e.position||i)&&t.height),n=s.findIndex(t=>t.id===e.id),l=s.filter((e,t)=>t<n&&e.visible).length;return s.filter(e=>e.visible).slice(...a?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+o,0)},[r]);return(0,s.useEffect)(()=>{r.forEach(e=>{if(e.dismissed)i(e.id,e.removeDelay);else{let t=o.get(e.id);t&&(clearTimeout(t),o.delete(e.id))}})},[r,i]),{toasts:r,handlers:{updateHeight:c,startPause:l,endPause:d,calculateOffset:u}}},F=x`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,Z=x`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,B=x`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,G=k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${F} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${Z} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${B} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,q=x`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,Y=k("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${q} 1s linear infinite;
`,J=x`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,V=x`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,X=k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${J} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${V} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,K=k("div")`
  position: absolute;
`,Q=k("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,ee=x`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,et=k("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${ee} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,er=({toast:e})=>{let{icon:t,type:r,iconTheme:a}=e;return void 0!==t?"string"==typeof t?s.createElement(et,null,t):t:"blank"===r?null:s.createElement(Q,null,s.createElement(Y,{...a}),"loading"!==r&&s.createElement(K,null,"error"===r?s.createElement(G,{...a}):s.createElement(X,{...a})))},ea=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,eo=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,ei=k("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,es=k("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,en=(e,t)=>{let r=e.includes("top")?1:-1,[a,o]=j()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[ea(r),eo(r)];return{animation:t?`${x(a)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${x(o)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},el=s.memo(({toast:e,position:t,style:r,children:a})=>{let o=e.height?en(e.position||t||"top-center",e.visible):{opacity:0},i=s.createElement(er,{toast:e}),n=s.createElement(es,{...e.ariaProps},E(e.message,e));return s.createElement(ei,{className:e.className,style:{...o,...r,...e.style}},"function"==typeof a?a({icon:i,message:n}):s.createElement(s.Fragment,null,i,n))});i=s.createElement,p.p=void 0,b=i,v=void 0,w=void 0;var ec=({id:e,className:t,style:r,onHeightUpdate:a,children:o})=>{let i=s.useCallback(t=>{if(t){let r=()=>{a(e,t.getBoundingClientRect().height)};r(),new MutationObserver(r).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,a]);return s.createElement("div",{ref:i,className:t,style:r},o)},ed=(e,t)=>{let r=e.includes("top"),a=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:j()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(r?1:-1)}px)`,...r?{top:0}:{bottom:0},...a}},eu=y`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ep=({reverseOrder:e,position:t="top-center",toastOptions:r,gutter:a,children:o,toasterId:i,containerStyle:n,containerClassName:l})=>{let{toasts:c,handlers:d}=U(r,i);return s.createElement("div",{"data-rht-toaster":i||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...n},className:l,onMouseEnter:d.startPause,onMouseLeave:d.endPause},c.map(r=>{let i=r.position||t,n=ed(i,d.calculateOffset(r,{reverseOrder:e,gutter:a,defaultPosition:t}));return s.createElement(ec,{id:r.id,key:r.id,onHeightUpdate:d.updateHeight,className:r.visible?eu:"",style:n},"custom"===r.type?E(r.message,r):o?o(r):s.createElement(el,{toast:r,position:i}))}))},em=W}}]);