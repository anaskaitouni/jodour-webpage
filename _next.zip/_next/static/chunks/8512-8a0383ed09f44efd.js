(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[8512],{7810:function(e,t,r){"use strict";r.d(t,{Z:function(){return i}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,r(2898).Z)("Heart",[["path",{d:"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z",key:"c3ymky"}]])},8004:function(e,t,r){"use strict";r.d(t,{Z:function(){return i}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,r(2898).Z)("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]])},4891:function(e,t,r){"use strict";r.d(t,{Z:function(){return i}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,r(2898).Z)("Minus",[["path",{d:"M5 12h14",key:"1ays0h"}]])},9883:function(e,t,r){"use strict";r.d(t,{Z:function(){return i}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,r(2898).Z)("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]])},6712:function(e,t,r){"use strict";r.d(t,{Z:function(){return i}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,r(2898).Z)("ShoppingBag",[["path",{d:"M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z",key:"hou9p0"}],["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M16 10a4 4 0 0 1-8 0",key:"1ltviw"}]])},1138:function(e,t,r){"use strict";r.d(t,{Z:function(){return i}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,r(2898).Z)("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]])},7972:function(e,t,r){"use strict";r.d(t,{Z:function(){return i}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,r(2898).Z)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])},2549:function(e,t,r){"use strict";r.d(t,{Z:function(){return i}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,r(2898).Z)("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]])},4033:function(e,t,r){e.exports=r(5313)},2167:function(e,t,r){"use strict";r.d(t,{M:function(){return y}});var i=r(2265),a=r(538);function n(){let e=(0,i.useRef)(!1);return(0,a.L)(()=>(e.current=!0,()=>{e.current=!1}),[]),e}var o=r(2363),s=r(8243),l=r(961);class c extends i.Component{getSnapshotBeforeUpdate(e){let t=this.props.childRef.current;if(t&&e.isPresent&&!this.props.isPresent){let e=this.props.sizeRef.current;e.height=t.offsetHeight||0,e.width=t.offsetWidth||0,e.top=t.offsetTop,e.left=t.offsetLeft}return null}componentDidUpdate(){}render(){return this.props.children}}function u({children:e,isPresent:t}){let r=(0,i.useId)(),a=(0,i.useRef)(null),n=(0,i.useRef)({width:0,height:0,top:0,left:0});return(0,i.useInsertionEffect)(()=>{let{width:e,height:i,top:o,left:s}=n.current;if(t||!a.current||!e||!i)return;a.current.dataset.motionPopId=r;let l=document.createElement("style");return document.head.appendChild(l),l.sheet&&l.sheet.insertRule(`
          [data-motion-pop-id="${r}"] {
            position: absolute !important;
            width: ${e}px !important;
            height: ${i}px !important;
            top: ${o}px !important;
            left: ${s}px !important;
          }
        `),()=>{document.head.removeChild(l)}},[t]),i.createElement(c,{isPresent:t,childRef:a,sizeRef:n},i.cloneElement(e,{ref:a}))}let d=({children:e,initial:t,isPresent:r,onExitComplete:a,custom:n,presenceAffectsLayout:o,mode:c})=>{let d=(0,l.h)(p),f=(0,i.useId)(),m=(0,i.useMemo)(()=>({id:f,initial:t,isPresent:r,custom:n,onExitComplete:e=>{for(let t of(d.set(e,!0),d.values()))if(!t)return;a&&a()},register:e=>(d.set(e,!1),()=>d.delete(e))}),o?void 0:[r]);return(0,i.useMemo)(()=>{d.forEach((e,t)=>d.set(t,!1))},[r]),i.useEffect(()=>{r||d.size||!a||a()},[r]),"popLayout"===c&&(e=i.createElement(u,{isPresent:r},e)),i.createElement(s.O.Provider,{value:m},e)};function p(){return new Map}var f=r(781),m=r(6567);let h=e=>e.key||"",y=({children:e,custom:t,initial:r=!0,onExitComplete:s,exitBeforeEnter:l,presenceAffectsLayout:c=!0,mode:u="sync"})=>{var p;(0,m.k)(!l,"Replace exitBeforeEnter with mode='wait'");let y=(0,i.useContext)(f.p).forceRender||function(){let e=n(),[t,r]=(0,i.useState)(0),a=(0,i.useCallback)(()=>{e.current&&r(t+1)},[t]);return[(0,i.useCallback)(()=>o.Wi.postRender(a),[a]),t]}()[0],g=n(),b=function(e){let t=[];return i.Children.forEach(e,e=>{(0,i.isValidElement)(e)&&t.push(e)}),t}(e),v=b,x=(0,i.useRef)(new Map).current,k=(0,i.useRef)(v),w=(0,i.useRef)(new Map).current,E=(0,i.useRef)(!0);if((0,a.L)(()=>{E.current=!1,function(e,t){e.forEach(e=>{let r=h(e);t.set(r,e)})}(b,w),k.current=v}),p=()=>{E.current=!0,w.clear(),x.clear()},(0,i.useEffect)(()=>()=>p(),[]),E.current)return i.createElement(i.Fragment,null,v.map(e=>i.createElement(d,{key:h(e),isPresent:!0,initial:!!r&&void 0,presenceAffectsLayout:c,mode:u},e)));v=[...v];let C=k.current.map(h),M=b.map(h),$=C.length;for(let e=0;e<$;e++){let t=C[e];-1!==M.indexOf(t)||x.has(t)||x.set(t,void 0)}return"wait"===u&&x.size&&(v=[]),x.forEach((e,r)=>{if(-1!==M.indexOf(r))return;let a=w.get(r);if(!a)return;let n=C.indexOf(r),o=e;o||(o=i.createElement(d,{key:h(a),isPresent:!1,onExitComplete:()=>{x.delete(r);let e=Array.from(w.keys()).filter(e=>!M.includes(e));if(e.forEach(e=>w.delete(e)),k.current=b.filter(t=>{let i=h(t);return i===r||e.includes(i)}),!x.size){if(!1===g.current)return;y(),s&&s()}},custom:t,presenceAffectsLayout:c,mode:u},a),x.set(r,o)),v.splice(n,0,o)}),v=v.map(e=>{let t=e.key;return x.has(t)?e:i.createElement(d,{key:h(e),isPresent:!0,presenceAffectsLayout:c,mode:u},e)}),i.createElement(i.Fragment,null,x.size?v:v.map(e=>(0,i.cloneElement)(e)))}},5925:function(e,t,r){"use strict";let i,a;r.r(t),r.d(t,{CheckmarkIcon:function(){return J},ErrorIcon:function(){return W},LoaderIcon:function(){return X},ToastBar:function(){return el},ToastIcon:function(){return er},Toaster:function(){return ep},default:function(){return ef},resolveValue:function(){return C},toast:function(){return H},useToaster:function(){return F},useToasterStore:function(){return N}});var n,o=r(2265);let s={data:""},l=e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||s},c=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,u=/\/\*[^]*?\*\/|  +/g,d=/\n+/g,p=(e,t)=>{let r="",i="",a="";for(let n in e){let o=e[n];"@"==n[0]?"i"==n[1]?r=n+" "+o+";":i+="f"==n[1]?p(o,n):n+"{"+p(o,"k"==n[1]?"":t)+"}":"object"==typeof o?i+=p(o,t?t.replace(/([^,])+/g,e=>n.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):n):null!=o&&(n="-"==n[1]?n:n.replace(/[A-Z]/g,"-$&").toLowerCase(),a+=p.p?p.p(n,o):n+":"+o+";")}return r+(t&&a?t+"{"+a+"}":a)+i},f={},m=e=>{if("object"==typeof e){let t="";for(let r in e)t+=r+m(e[r]);return t}return e},h=(e,t,r,i,a)=>{var n;let o=m(e),s=f[o]||(f[o]=(e=>{let t=0,r=11;for(;t<e.length;)r=101*r+e.charCodeAt(t++)>>>0;return"go"+r})(o));if(!f[s]){let t=o!==e?e:(e=>{let t,r,i=[{}];for(;t=c.exec(e.replace(u,""));)t[4]?i.shift():t[3]?(r=t[3].replace(d," ").trim(),i.unshift(i[0][r]=i[0][r]||{})):i[0][t[1]]=t[2].replace(d," ").trim();return i[0]})(e);f[s]=p(a?{["@keyframes "+s]:t}:t,r?"":"."+s)}let l=r&&f.g;return r&&(f.g=f[s]),n=f[s],l?t.data=t.data.replace(l,n):-1===t.data.indexOf(n)&&(t.data=i?n+t.data:t.data+n),s},y=(e,t,r)=>e.reduce((e,i,a)=>{let n=t[a];if(n&&n.call){let e=n(r),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;n=t?"."+t:e&&"object"==typeof e?e.props?"":p(e,""):!1===e?"":e}return e+i+(null==n?"":n)},"");function g(e){let t=this||{},r=e.call?e(t.p):e;return h(r.unshift?r.raw?y(r,[].slice.call(arguments,1),t.p):r.reduce((e,r)=>Object.assign(e,r&&r.call?r(t.p):r),{}):r,l(t.target),t.g,t.o,t.k)}g.bind({g:1});let b,v,x,k=g.bind({k:1});function w(e,t){let r=this||{};return function(){let i=arguments;function a(n,o){let s=Object.assign({},n),l=s.className||a.className;r.p=Object.assign({theme:v&&v()},s),r.o=/go\d/.test(l),s.className=g.apply(r,i)+(l?" "+l:""),t&&(s.ref=o);let c=e;return e[0]&&(c=s.as||e,delete s.as),x&&c[0]&&x(s),b(c,s)}return t?t(a):a}}var E=e=>"function"==typeof e,C=(e,t)=>E(e)?e(t):e,M=(i=0,()=>(++i).toString()),$=()=>{if(void 0===a&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");a=!e||e.matches}return a},I="default",Z=(e,t)=>{let{toastLimit:r}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,r)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:i}=t;return Z(e,{type:e.toasts.find(e=>e.id===i.id)?1:0,toast:i});case 3:let{toastId:a}=t;return{...e,toasts:e.toasts.map(e=>e.id===a||void 0===a?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let n=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+n}))}}},O=[],P={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},R={},j=(e,t=I)=>{R[t]=Z(R[t]||P,e),O.forEach(([e,r])=>{e===t&&r(R[t])})},z=e=>Object.keys(R).forEach(t=>j(e,t)),A=e=>Object.keys(R).find(t=>R[t].toasts.some(t=>t.id===e)),D=(e=I)=>t=>{j(t,e)},L={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},N=(e={},t=I)=>{let[r,i]=(0,o.useState)(R[t]||P),a=(0,o.useRef)(R[t]);(0,o.useEffect)(()=>(a.current!==R[t]&&i(R[t]),O.push([t,i]),()=>{let e=O.findIndex(([e])=>e===t);e>-1&&O.splice(e,1)}),[t]);let n=r.toasts.map(t=>{var r,i,a;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(r=e[t.type])?void 0:r.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(i=e[t.type])?void 0:i.duration)||(null==e?void 0:e.duration)||L[t.type],style:{...e.style,...null==(a=e[t.type])?void 0:a.style,...t.style}}});return{...r,toasts:n}},T=(e,t="blank",r)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...r,id:(null==r?void 0:r.id)||M()}),_=e=>(t,r)=>{let i=T(t,e,r);return D(i.toasterId||A(i.id))({type:2,toast:i}),i.id},H=(e,t)=>_("blank")(e,t);H.error=_("error"),H.success=_("success"),H.loading=_("loading"),H.custom=_("custom"),H.dismiss=(e,t)=>{let r={type:3,toastId:e};t?D(t)(r):z(r)},H.dismissAll=e=>H.dismiss(void 0,e),H.remove=(e,t)=>{let r={type:4,toastId:e};t?D(t)(r):z(r)},H.removeAll=e=>H.remove(void 0,e),H.promise=(e,t,r)=>{let i=H.loading(t.loading,{...r,...null==r?void 0:r.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let a=t.success?C(t.success,e):void 0;return a?H.success(a,{id:i,...r,...null==r?void 0:r.success}):H.dismiss(i),e}).catch(e=>{let a=t.error?C(t.error,e):void 0;a?H.error(a,{id:i,...r,...null==r?void 0:r.error}):H.dismiss(i)}),e};var S=1e3,F=(e,t="default")=>{let{toasts:r,pausedAt:i}=N(e,t),a=(0,o.useRef)(new Map).current,n=(0,o.useCallback)((e,t=S)=>{if(a.has(e))return;let r=setTimeout(()=>{a.delete(e),s({type:4,toastId:e})},t);a.set(e,r)},[]);(0,o.useEffect)(()=>{if(i)return;let e=Date.now(),a=r.map(r=>{if(r.duration===1/0)return;let i=(r.duration||0)+r.pauseDuration-(e-r.createdAt);if(i<0){r.visible&&H.dismiss(r.id);return}return setTimeout(()=>H.dismiss(r.id,t),i)});return()=>{a.forEach(e=>e&&clearTimeout(e))}},[r,i,t]);let s=(0,o.useCallback)(D(t),[t]),l=(0,o.useCallback)(()=>{s({type:5,time:Date.now()})},[s]),c=(0,o.useCallback)((e,t)=>{s({type:1,toast:{id:e,height:t}})},[s]),u=(0,o.useCallback)(()=>{i&&s({type:6,time:Date.now()})},[i,s]),d=(0,o.useCallback)((e,t)=>{let{reverseOrder:i=!1,gutter:a=8,defaultPosition:n}=t||{},o=r.filter(t=>(t.position||n)===(e.position||n)&&t.height),s=o.findIndex(t=>t.id===e.id),l=o.filter((e,t)=>t<s&&e.visible).length;return o.filter(e=>e.visible).slice(...i?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+a,0)},[r]);return(0,o.useEffect)(()=>{r.forEach(e=>{if(e.dismissed)n(e.id,e.removeDelay);else{let t=a.get(e.id);t&&(clearTimeout(t),a.delete(e.id))}})},[r,n]),{toasts:r,handlers:{updateHeight:c,startPause:l,endPause:u,calculateOffset:d}}},B=k`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,U=k`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,V=k`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,W=w("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${B} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${U} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${V} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,q=k`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,X=w("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${q} 1s linear infinite;
`,Y=k`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,G=k`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,J=w("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${Y} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${G} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,K=w("div")`
  position: absolute;
`,Q=w("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,ee=k`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,et=w("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${ee} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,er=({toast:e})=>{let{icon:t,type:r,iconTheme:i}=e;return void 0!==t?"string"==typeof t?o.createElement(et,null,t):t:"blank"===r?null:o.createElement(Q,null,o.createElement(X,{...i}),"loading"!==r&&o.createElement(K,null,"error"===r?o.createElement(W,{...i}):o.createElement(J,{...i})))},ei=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,ea=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,en=w("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,eo=w("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,es=(e,t)=>{let r=e.includes("top")?1:-1,[i,a]=$()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[ei(r),ea(r)];return{animation:t?`${k(i)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${k(a)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},el=o.memo(({toast:e,position:t,style:r,children:i})=>{let a=e.height?es(e.position||t||"top-center",e.visible):{opacity:0},n=o.createElement(er,{toast:e}),s=o.createElement(eo,{...e.ariaProps},C(e.message,e));return o.createElement(en,{className:e.className,style:{...a,...r,...e.style}},"function"==typeof i?i({icon:n,message:s}):o.createElement(o.Fragment,null,n,s))});n=o.createElement,p.p=void 0,b=n,v=void 0,x=void 0;var ec=({id:e,className:t,style:r,onHeightUpdate:i,children:a})=>{let n=o.useCallback(t=>{if(t){let r=()=>{i(e,t.getBoundingClientRect().height)};r(),new MutationObserver(r).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,i]);return o.createElement("div",{ref:n,className:t,style:r},a)},eu=(e,t)=>{let r=e.includes("top"),i=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:$()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(r?1:-1)}px)`,...r?{top:0}:{bottom:0},...i}},ed=g`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ep=({reverseOrder:e,position:t="top-center",toastOptions:r,gutter:i,children:a,toasterId:n,containerStyle:s,containerClassName:l})=>{let{toasts:c,handlers:u}=F(r,n);return o.createElement("div",{"data-rht-toaster":n||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...s},className:l,onMouseEnter:u.startPause,onMouseLeave:u.endPause},c.map(r=>{let n=r.position||t,s=eu(n,u.calculateOffset(r,{reverseOrder:e,gutter:i,defaultPosition:t}));return o.createElement(ec,{id:r.id,key:r.id,onHeightUpdate:u.updateHeight,className:r.visible?ed:"",style:s},"custom"===r.type?C(r.message,r):a?a(r):o.createElement(el,{toast:r,position:n}))}))},ef=H}}]);