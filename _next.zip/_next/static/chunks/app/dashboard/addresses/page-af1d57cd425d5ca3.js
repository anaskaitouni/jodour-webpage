(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[489,8228],{6142:function(e,t,a){"use strict";a.d(t,{Z:function(){return s}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(2898).Z)("MapPin",[["path",{d:"M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z",key:"2oe9fu"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]])},9883:function(e,t,a){"use strict";a.d(t,{Z:function(){return s}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(2898).Z)("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]])},1138:function(e,t,a){"use strict";a.d(t,{Z:function(){return s}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(2898).Z)("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]])},8816:function(e,t,a){Promise.resolve().then(a.bind(a,9073))},9073:function(e,t,a){"use strict";a.r(t),a.d(t,{default:function(){return f}});var s=a(7437),r=a(2265),i=a(1396),o=a.n(i),n=a(5251),l=a(9883),c=a(6142),d=a(1138),u=a(8228),p=a(4033),m=a(1865),h=a(5925),g=a(8222);function f(){let{user:e}=(0,u.useAuthStore)(),t=(0,p.useRouter)(),[a,i]=(0,r.useState)([]),[f,x]=(0,r.useState)(!0),[y,b]=(0,r.useState)(!1),{register:v,handleSubmit:w,reset:k,formState:{errors:j}}=(0,m.cI)();(0,r.useEffect)(()=>{if(!e){t.push("/auth/login");return}g.Z.get("/users/addresses").then(e=>i(e.data)).catch(()=>{}).finally(()=>x(!1))},[e,t]);let N=async e=>{try{let t=await g.Z.post("/users/addresses",e);i(e=>[...e,t.data]),b(!1),k(),h.default.success("Address added")}catch(e){h.default.error("Failed to add address")}},C=async e=>{try{await g.Z.delete("/users/addresses/".concat(e)),i(t=>t.filter(t=>t.id!==e)),h.default.success("Address removed")}catch(e){h.default.error("Failed")}};return e?(0,s.jsx)("div",{className:"min-h-screen pt-24 px-[var(--gutter)] py-12",children:(0,s.jsxs)("div",{className:"max-w-2xl",children:[(0,s.jsxs)("div",{className:"flex items-center justify-between mb-8",children:[(0,s.jsxs)("div",{className:"flex items-center gap-3",children:[(0,s.jsx)(o(),{href:"/dashboard",className:"font-gothic text-xs text-gray-500 hover:text-white",children:"Account"}),(0,s.jsx)("span",{className:"text-gray-700",children:"/"}),(0,s.jsx)("h1",{className:"font-gothic text-2xl font-light",children:"Addresses"})]}),(0,s.jsxs)("button",{onClick:()=>b(!y),className:"btn-outline text-sm py-2",children:[(0,s.jsx)(l.Z,{size:14})," Add Address"]})]}),y&&(0,s.jsxs)(n.E.div,{initial:{opacity:0,y:-10},animate:{opacity:1,y:0},className:"border border-white/10 p-8 mb-8",children:[(0,s.jsx)("h2",{className:"font-gothic text-sm font-light mb-6",children:"New Address"}),(0,s.jsxs)("form",{onSubmit:w(N),className:"space-y-6",children:[(0,s.jsxs)("div",{className:"grid grid-cols-2 gap-5",children:[(0,s.jsxs)("div",{className:"col-span-2",children:[(0,s.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Full Name"}),(0,s.jsx)("input",{...v("name",{required:!0}),className:"input-luxury"})]}),(0,s.jsxs)("div",{className:"col-span-2",children:[(0,s.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Address Line 1"}),(0,s.jsx)("input",{...v("line1",{required:!0}),className:"input-luxury"})]}),(0,s.jsxs)("div",{className:"col-span-2",children:[(0,s.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Address Line 2"}),(0,s.jsx)("input",{...v("line2"),className:"input-luxury"})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"City"}),(0,s.jsx)("input",{...v("city",{required:!0}),className:"input-luxury"})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Postal Code"}),(0,s.jsx)("input",{...v("postalCode",{required:!0}),className:"input-luxury"})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Country"}),(0,s.jsx)("input",{...v("country",{required:!0}),className:"input-luxury"})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Phone"}),(0,s.jsx)("input",{...v("phone"),className:"input-luxury"})]})]}),(0,s.jsxs)("label",{className:"flex items-center gap-2 cursor-pointer",children:[(0,s.jsx)("input",{...v("isDefault"),type:"checkbox",className:"w-4 h-4 accent-[#8C1515]"}),(0,s.jsx)("span",{className:"font-gothic text-xs text-gray-400",children:"Set as default address"})]}),(0,s.jsxs)("div",{className:"flex gap-3",children:[(0,s.jsx)("button",{type:"submit",className:"btn-luxury",children:"Save Address"}),(0,s.jsx)("button",{type:"button",onClick:()=>b(!1),className:"btn-outline",children:"Cancel"})]})]})]}),f?(0,s.jsx)("div",{className:"space-y-3",children:[1,2].map(e=>(0,s.jsx)("div",{className:"h-32 bg-[#111] animate-pulse rounded"},e))}):0!==a.length||y?(0,s.jsx)("div",{className:"space-y-4",children:a.map((e,t)=>(0,s.jsxs)(n.E.div,{initial:{opacity:0,y:10},animate:{opacity:1,y:0},transition:{delay:.05*t},className:"border border-white/10 p-6 relative hover:border-white/20 transition-colors",children:[e.isDefault&&(0,s.jsx)("span",{className:"absolute top-4 right-14 font-gothic text-[9px] tracking-[2px] uppercase text-[#8C1515]",children:"Default"}),(0,s.jsx)("button",{onClick:()=>C(e.id),className:"absolute top-4 right-4 text-gray-600 hover:text-[#8C1515] transition-colors",children:(0,s.jsx)(d.Z,{size:14})}),(0,s.jsx)("p",{className:"font-gothic text-sm text-white mb-1",children:e.name}),(0,s.jsxs)("p",{className:"font-gothic text-sm text-gray-500",children:[e.line1,e.line2?", ".concat(e.line2):""]}),(0,s.jsxs)("p",{className:"font-gothic text-sm text-gray-500",children:[e.city,", ",e.postalCode]}),(0,s.jsx)("p",{className:"font-gothic text-sm text-gray-500",children:e.country}),e.phone&&(0,s.jsx)("p",{className:"font-gothic text-sm text-gray-500 mt-1",children:e.phone})]},e.id))}):(0,s.jsxs)("div",{className:"text-center py-20 border border-white/5",children:[(0,s.jsx)(c.Z,{size:32,className:"text-gray-700 mx-auto mb-4"}),(0,s.jsx)("p",{className:"font-gothic text-gray-500 text-sm",children:"No addresses saved yet"})]})]})}):null}},8222:function(e,t,a){"use strict";var s=a(7541);let r=[{id:"seating",name:"Seating",slug:"seating"},{id:"objects",name:"Objects",slug:"objects"},{id:"lighting",name:"Lighting",slug:"lighting"}];function i(e){return Promise.resolve({data:e})}t.Z={get:e=>{if(e.startsWith("/products?featured")||e.startsWith("/products?"))return i({products:s.n6,pagination:{total:s.n6.length}});if(e.startsWith("/products/")){let t=e.replace("/products/","").split("?")[0],a=s.n6.find(e=>e.slug===t);return a?i(a):Promise.reject(Error("Not found"))}return"/categories"===e?i(r):"/collections"===e?i(s.jn):"/orders"===e||e.startsWith("/users/wishlist")||e.startsWith("/users/addresses")?i([]):i({})},post:(e,t)=>"/auth/login"===e?i({user:{id:"mock-user",name:"Guest User",email:(null==t?void 0:t.email)||"user@jodour.com",role:"USER"},accessToken:"mock-token"}):"/auth/register"===e?i({user:{id:"mock-user",name:(null==t?void 0:t.name)||"Guest User",email:(null==t?void 0:t.email)||"user@jodour.com",role:"USER"},accessToken:"mock-token"}):"/auth/logout"===e?i({}):"/auth/refresh"===e?Promise.reject(Error("No refresh")):"/messages"===e||"/newsletter"===e?i({success:!0}):"/users/addresses"===e?i({id:"mock-address"}):"/orders"===e?i({id:"mock-order",orderNumber:"JOD-"+Math.floor(9e4*Math.random()+1e4)}):e.startsWith("/payments/")?i({url:"/checkout/success"}):e.startsWith("/users/wishlist/")?i({added:!0}):i({}),put:(e,t)=>i({}),patch:(e,t)=>i({}),delete:e=>i({}),defaults:{headers:{common:{}}},interceptors:{request:{use:()=>{}},response:{use:()=>{}}}}},7541:function(e,t,a){"use strict";a.d(t,{OX:function(){return n},jn:function(){return o},n6:function(){return i}});let s="/assets/products";function r(e,t,a){return Array.from({length:t},(t,r)=>({id:"".concat(e,"-").concat(r+1),url:"".concat(s,"/").concat(e,"-").concat(r+1,".png"),alt:0===r?a:"".concat(a," view ").concat(r+1)}))}let i=[{id:"cloud",title:"Cloud",slug:"cloud",price:1890,comparePrice:2200,limited:!0,stock:12,featured:!0,description:"An sculptural office chair blending organic copper forms with textured upholstery — where Moroccan craftsmanship meets contemporary workspace design.",story:"Inspired by desert clouds and the soft curves of Atlas landscapes, Cloud reimagines the executive chair as a collectible design object.",images:[{id:"cloud-1",url:"".concat(s,"/cloud-1.png"),alt:"Cloud chair"},{id:"cloud-2",url:"".concat(s,"/cloud-2.png"),alt:"Cloud chair view 2"},{id:"cloud-4",url:"".concat(s,"/cloud-4.png"),alt:"Cloud chair view 3"},{id:"cloud-5",url:"".concat(s,"/cloud-5.png"),alt:"Cloud chair view 4"},{id:"cloud-6",url:"".concat(s,"/cloud-6.png"),alt:"Cloud chair view 5"}],category:{name:"Seating",slug:"seating"},collection:{name:"Cloud Collection",slug:"cloud"},materials:[{id:"m1",name:"Copper"},{id:"m2",name:"Wool upholstery"}],dimensions:{width:65,height:120,depth:70,weight:18,unit:"cm"},reviews:[],_count:{reviews:0},related:[]},{id:"chelal",title:"Chelal",slug:"chelal",price:450,limited:!0,stock:24,featured:!0,description:"A luxury electric kettle adorned with traditional Moroccan filigree patterns in gold and bronze — heritage reimagined for the modern kitchen.",story:"Chelal draws from the ornate metalwork of Moroccan tea culture, transforming an everyday ritual into a moment of design.",images:r("chelal",4,"Chelal kettle"),category:{name:"Objects",slug:"objects"},collection:{name:"Chelal Collection",slug:"chelal"},materials:[{id:"m3",name:"Matte ceramic"},{id:"m4",name:"Gold filigree"}],dimensions:{width:22,height:28,depth:22,weight:1.8,unit:"cm"},reviews:[],_count:{reviews:0},related:[]},{id:"manara",title:"Manara",slug:"manara",price:680,limited:!0,stock:18,featured:!0,description:"Hammered copper table lamps with patterned ceramic bases — light as sculpture, rooted in Moroccan decorative tradition.",story:"Manara, meaning lighthouse, guides the eye through concentric copper rings that diffuse warm, ambient light.",images:r("manara",5,"Manara lamp"),category:{name:"Lighting",slug:"lighting"},collection:{name:"Manara Collection",slug:"manara"},materials:[{id:"m5",name:"Hammered copper"},{id:"m6",name:"Ceramic"}],dimensions:{width:35,height:55,depth:35,weight:3.2,unit:"cm"},reviews:[],_count:{reviews:0},related:[]}],o=[{id:"cloud",name:"Cloud",slug:"cloud",description:"Sculptural seating — copper and wool in organic harmony.",image:"".concat(s,"/cloud-1.png"),featured:!0,_count:{products:1}},{id:"chelal",name:"Chelal",slug:"chelal",description:"Moroccan filigree meets modern kitchen ritual.",image:"".concat(s,"/chelal-1.png"),featured:!0,_count:{products:1}},{id:"manara",name:"Manara",slug:"manara",description:"Hammered copper lighting — light as collectible art.",image:"".concat(s,"/manara-1.png"),featured:!0,_count:{products:1}}];function n(e){let t=i.find(t=>t.slug===e);if(!t)return null;let a=i.filter(t=>t.slug!==e).map(e=>({id:e.id,title:e.title,price:e.price,slug:e.slug,images:e.images}));return{...t,related:a}}},8228:function(e,t,a){"use strict";a.d(t,{useAuthStore:function(){return o}});var s=a(4660),r=a(4810),i=a(8222);let o=(0,s.Ue)()((0,r.tJ)(e=>({user:null,accessToken:null,isLoading:!1,login:async(t,a)=>{e({isLoading:!0}),await new Promise(e=>setTimeout(e,600));try{let s=await i.Z.post("/auth/login",{email:t,password:a});e({user:s.data.user,accessToken:s.data.accessToken,isLoading:!1})}catch(t){throw e({isLoading:!1}),Error("Login failed")}},register:async(t,a,s)=>{e({isLoading:!0}),await new Promise(e=>setTimeout(e,600));try{let s=await i.Z.post("/auth/register",{name:t,email:a});e({user:s.data.user,accessToken:s.data.accessToken,isLoading:!1})}catch(t){throw e({isLoading:!1}),Error("Registration failed")}},logout:async()=>{e({user:null,accessToken:null})},refreshToken:async()=>!1,setUser:t=>e({user:t}),setToken:t=>e({accessToken:t})}),{name:"jodour-auth",partialize:e=>({user:e.user,accessToken:e.accessToken})}))},4033:function(e,t,a){e.exports=a(5313)},5925:function(e,t,a){"use strict";let s,r;a.r(t),a.d(t,{CheckmarkIcon:function(){return Y},ErrorIcon:function(){return G},LoaderIcon:function(){return B},ToastBar:function(){return el},ToastIcon:function(){return ea},Toaster:function(){return ep},default:function(){return em},resolveValue:function(){return N},toast:function(){return H},useToaster:function(){return F},useToasterStore:function(){return I}});var i,o=a(2265);let n={data:""},l=e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||n},c=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,d=/\/\*[^]*?\*\/|  +/g,u=/\n+/g,p=(e,t)=>{let a="",s="",r="";for(let i in e){let o=e[i];"@"==i[0]?"i"==i[1]?a=i+" "+o+";":s+="f"==i[1]?p(o,i):i+"{"+p(o,"k"==i[1]?"":t)+"}":"object"==typeof o?s+=p(o,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=o&&(i="-"==i[1]?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),r+=p.p?p.p(i,o):i+":"+o+";")}return a+(t&&r?t+"{"+r+"}":r)+s},m={},h=e=>{if("object"==typeof e){let t="";for(let a in e)t+=a+h(e[a]);return t}return e},g=(e,t,a,s,r)=>{var i;let o=h(e),n=m[o]||(m[o]=(e=>{let t=0,a=11;for(;t<e.length;)a=101*a+e.charCodeAt(t++)>>>0;return"go"+a})(o));if(!m[n]){let t=o!==e?e:(e=>{let t,a,s=[{}];for(;t=c.exec(e.replace(d,""));)t[4]?s.shift():t[3]?(a=t[3].replace(u," ").trim(),s.unshift(s[0][a]=s[0][a]||{})):s[0][t[1]]=t[2].replace(u," ").trim();return s[0]})(e);m[n]=p(r?{["@keyframes "+n]:t}:t,a?"":"."+n)}let l=a&&m.g;return a&&(m.g=m[n]),i=m[n],l?t.data=t.data.replace(l,i):-1===t.data.indexOf(i)&&(t.data=s?i+t.data:t.data+i),n},f=(e,t,a)=>e.reduce((e,s,r)=>{let i=t[r];if(i&&i.call){let e=i(a),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":p(e,""):!1===e?"":e}return e+s+(null==i?"":i)},"");function x(e){let t=this||{},a=e.call?e(t.p):e;return g(a.unshift?a.raw?f(a,[].slice.call(arguments,1),t.p):a.reduce((e,a)=>Object.assign(e,a&&a.call?a(t.p):a),{}):a,l(t.target),t.g,t.o,t.k)}x.bind({g:1});let y,b,v,w=x.bind({k:1});function k(e,t){let a=this||{};return function(){let s=arguments;function r(i,o){let n=Object.assign({},i),l=n.className||r.className;a.p=Object.assign({theme:b&&b()},n),a.o=/go\d/.test(l),n.className=x.apply(a,s)+(l?" "+l:""),t&&(n.ref=o);let c=e;return e[0]&&(c=n.as||e,delete n.as),v&&c[0]&&v(n),y(c,n)}return t?t(r):r}}var j=e=>"function"==typeof e,N=(e,t)=>j(e)?e(t):e,C=(s=0,()=>(++s).toString()),E=()=>{if(void 0===r&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");r=!e||e.matches}return r},A="default",T=(e,t)=>{let{toastLimit:a}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,a)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:s}=t;return T(e,{type:e.toasts.find(e=>e.id===s.id)?1:0,toast:s});case 3:let{toastId:r}=t;return{...e,toasts:e.toasts.map(e=>e.id===r||void 0===r?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},M=[],O={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},S={},L=(e,t=A)=>{S[t]=T(S[t]||O,e),M.forEach(([e,a])=>{e===t&&a(S[t])})},P=e=>Object.keys(S).forEach(t=>L(e,t)),$=e=>Object.keys(S).find(t=>S[t].toasts.some(t=>t.id===e)),_=(e=A)=>t=>{L(t,e)},D={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},I=(e={},t=A)=>{let[a,s]=(0,o.useState)(S[t]||O),r=(0,o.useRef)(S[t]);(0,o.useEffect)(()=>(r.current!==S[t]&&s(S[t]),M.push([t,s]),()=>{let e=M.findIndex(([e])=>e===t);e>-1&&M.splice(e,1)}),[t]);let i=a.toasts.map(t=>{var a,s,r;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(a=e[t.type])?void 0:a.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(s=e[t.type])?void 0:s.duration)||(null==e?void 0:e.duration)||D[t.type],style:{...e.style,...null==(r=e[t.type])?void 0:r.style,...t.style}}});return{...a,toasts:i}},Z=(e,t="blank",a)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:(null==a?void 0:a.id)||C()}),z=e=>(t,a)=>{let s=Z(t,e,a);return _(s.toasterId||$(s.id))({type:2,toast:s}),s.id},H=(e,t)=>z("blank")(e,t);H.error=z("error"),H.success=z("success"),H.loading=z("loading"),H.custom=z("custom"),H.dismiss=(e,t)=>{let a={type:3,toastId:e};t?_(t)(a):P(a)},H.dismissAll=e=>H.dismiss(void 0,e),H.remove=(e,t)=>{let a={type:4,toastId:e};t?_(t)(a):P(a)},H.removeAll=e=>H.remove(void 0,e),H.promise=(e,t,a)=>{let s=H.loading(t.loading,{...a,...null==a?void 0:a.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let r=t.success?N(t.success,e):void 0;return r?H.success(r,{id:s,...a,...null==a?void 0:a.success}):H.dismiss(s),e}).catch(e=>{let r=t.error?N(t.error,e):void 0;r?H.error(r,{id:s,...a,...null==a?void 0:a.error}):H.dismiss(s)}),e};var q=1e3,F=(e,t="default")=>{let{toasts:a,pausedAt:s}=I(e,t),r=(0,o.useRef)(new Map).current,i=(0,o.useCallback)((e,t=q)=>{if(r.has(e))return;let a=setTimeout(()=>{r.delete(e),n({type:4,toastId:e})},t);r.set(e,a)},[]);(0,o.useEffect)(()=>{if(s)return;let e=Date.now(),r=a.map(a=>{if(a.duration===1/0)return;let s=(a.duration||0)+a.pauseDuration-(e-a.createdAt);if(s<0){a.visible&&H.dismiss(a.id);return}return setTimeout(()=>H.dismiss(a.id,t),s)});return()=>{r.forEach(e=>e&&clearTimeout(e))}},[a,s,t]);let n=(0,o.useCallback)(_(t),[t]),l=(0,o.useCallback)(()=>{n({type:5,time:Date.now()})},[n]),c=(0,o.useCallback)((e,t)=>{n({type:1,toast:{id:e,height:t}})},[n]),d=(0,o.useCallback)(()=>{s&&n({type:6,time:Date.now()})},[s,n]),u=(0,o.useCallback)((e,t)=>{let{reverseOrder:s=!1,gutter:r=8,defaultPosition:i}=t||{},o=a.filter(t=>(t.position||i)===(e.position||i)&&t.height),n=o.findIndex(t=>t.id===e.id),l=o.filter((e,t)=>t<n&&e.visible).length;return o.filter(e=>e.visible).slice(...s?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+r,0)},[a]);return(0,o.useEffect)(()=>{a.forEach(e=>{if(e.dismissed)i(e.id,e.removeDelay);else{let t=r.get(e.id);t&&(clearTimeout(t),r.delete(e.id))}})},[a,i]),{toasts:a,handlers:{updateHeight:c,startPause:l,endPause:d,calculateOffset:u}}},U=w`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,W=w`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,R=w`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,G=k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${U} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${W} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${R} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,V=w`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,B=k("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${V} 1s linear infinite;
`,J=w`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,X=w`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,Y=k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${J} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${X} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,K=k("div")`
  position: absolute;
`,Q=k("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,ee=w`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,et=k("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${ee} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,ea=({toast:e})=>{let{icon:t,type:a,iconTheme:s}=e;return void 0!==t?"string"==typeof t?o.createElement(et,null,t):t:"blank"===a?null:o.createElement(Q,null,o.createElement(B,{...s}),"loading"!==a&&o.createElement(K,null,"error"===a?o.createElement(G,{...s}):o.createElement(Y,{...s})))},es=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,er=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,ei=k("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,eo=k("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,en=(e,t)=>{let a=e.includes("top")?1:-1,[s,r]=E()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[es(a),er(a)];return{animation:t?`${w(s)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${w(r)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},el=o.memo(({toast:e,position:t,style:a,children:s})=>{let r=e.height?en(e.position||t||"top-center",e.visible):{opacity:0},i=o.createElement(ea,{toast:e}),n=o.createElement(eo,{...e.ariaProps},N(e.message,e));return o.createElement(ei,{className:e.className,style:{...r,...a,...e.style}},"function"==typeof s?s({icon:i,message:n}):o.createElement(o.Fragment,null,i,n))});i=o.createElement,p.p=void 0,y=i,b=void 0,v=void 0;var ec=({id:e,className:t,style:a,onHeightUpdate:s,children:r})=>{let i=o.useCallback(t=>{if(t){let a=()=>{s(e,t.getBoundingClientRect().height)};a(),new MutationObserver(a).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,s]);return o.createElement("div",{ref:i,className:t,style:a},r)},ed=(e,t)=>{let a=e.includes("top"),s=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:E()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(a?1:-1)}px)`,...a?{top:0}:{bottom:0},...s}},eu=x`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ep=({reverseOrder:e,position:t="top-center",toastOptions:a,gutter:s,children:r,toasterId:i,containerStyle:n,containerClassName:l})=>{let{toasts:c,handlers:d}=F(a,i);return o.createElement("div",{"data-rht-toaster":i||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...n},className:l,onMouseEnter:d.startPause,onMouseLeave:d.endPause},c.map(a=>{let i=a.position||t,n=ed(i,d.calculateOffset(a,{reverseOrder:e,gutter:s,defaultPosition:t}));return o.createElement(ec,{id:a.id,key:a.id,onHeightUpdate:d.updateHeight,className:a.visible?eu:"",style:n},"custom"===a.type?N(a.message,a):r?r(a):o.createElement(el,{toast:a,position:i}))}))},em=H}},function(e){e.O(0,[4581,1396,5166,1865,2971,4938,1744],function(){return e(e.s=8816)}),_N_E=e.O()}]);