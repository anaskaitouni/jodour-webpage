(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[489,8228],{6142:function(e,t,s){"use strict";s.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(2898).Z)("MapPin",[["path",{d:"M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z",key:"2oe9fu"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]])},9883:function(e,t,s){"use strict";s.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(2898).Z)("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]])},1138:function(e,t,s){"use strict";s.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(2898).Z)("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]])},8816:function(e,t,s){Promise.resolve().then(s.bind(s,9073))},9073:function(e,t,s){"use strict";s.r(t),s.d(t,{default:function(){return g}});var a=s(7437),r=s(2265),i=s(1396),o=s.n(i),n=s(5251),l=s(9883),c=s(6142),d=s(1138),u=s(8228),p=s(4033),m=s(1865),h=s(5925),f=s(8222);function g(){let{user:e}=(0,u.useAuthStore)(),t=(0,p.useRouter)(),[s,i]=(0,r.useState)([]),[g,x]=(0,r.useState)(!0),[y,b]=(0,r.useState)(!1),{register:v,handleSubmit:k,reset:w,formState:{errors:j}}=(0,m.cI)();(0,r.useEffect)(()=>{if(!e){t.push("/auth/login");return}f.Z.get("/users/addresses").then(e=>i(e.data)).catch(()=>{}).finally(()=>x(!1))},[e,t]);let N=async e=>{try{let t=await f.Z.post("/users/addresses",e);i(e=>[...e,t.data]),b(!1),w(),h.default.success("Address added")}catch(e){h.default.error("Failed to add address")}},C=async e=>{try{await f.Z.delete("/users/addresses/".concat(e)),i(t=>t.filter(t=>t.id!==e)),h.default.success("Address removed")}catch(e){h.default.error("Failed")}};return e?(0,a.jsx)("div",{className:"min-h-screen pt-24 px-[var(--gutter)] py-12",children:(0,a.jsxs)("div",{className:"max-w-2xl",children:[(0,a.jsxs)("div",{className:"flex items-center justify-between mb-8",children:[(0,a.jsxs)("div",{className:"flex items-center gap-3",children:[(0,a.jsx)(o(),{href:"/dashboard",className:"font-gothic text-xs text-gray-500 hover:text-white",children:"Account"}),(0,a.jsx)("span",{className:"text-gray-700",children:"/"}),(0,a.jsx)("h1",{className:"font-gothic text-2xl font-light",children:"Addresses"})]}),(0,a.jsxs)("button",{onClick:()=>b(!y),className:"btn-outline text-sm py-2",children:[(0,a.jsx)(l.Z,{size:14})," Add Address"]})]}),y&&(0,a.jsxs)(n.E.div,{initial:{opacity:0,y:-10},animate:{opacity:1,y:0},className:"border border-white/10 p-8 mb-8",children:[(0,a.jsx)("h2",{className:"font-gothic text-sm font-light mb-6",children:"New Address"}),(0,a.jsxs)("form",{onSubmit:k(N),className:"space-y-6",children:[(0,a.jsxs)("div",{className:"grid grid-cols-2 gap-5",children:[(0,a.jsxs)("div",{className:"col-span-2",children:[(0,a.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Full Name"}),(0,a.jsx)("input",{...v("name",{required:!0}),className:"input-luxury"})]}),(0,a.jsxs)("div",{className:"col-span-2",children:[(0,a.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Address Line 1"}),(0,a.jsx)("input",{...v("line1",{required:!0}),className:"input-luxury"})]}),(0,a.jsxs)("div",{className:"col-span-2",children:[(0,a.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Address Line 2"}),(0,a.jsx)("input",{...v("line2"),className:"input-luxury"})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"City"}),(0,a.jsx)("input",{...v("city",{required:!0}),className:"input-luxury"})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Postal Code"}),(0,a.jsx)("input",{...v("postalCode",{required:!0}),className:"input-luxury"})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Country"}),(0,a.jsx)("input",{...v("country",{required:!0}),className:"input-luxury"})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Phone"}),(0,a.jsx)("input",{...v("phone"),className:"input-luxury"})]})]}),(0,a.jsxs)("label",{className:"flex items-center gap-2 cursor-pointer",children:[(0,a.jsx)("input",{...v("isDefault"),type:"checkbox",className:"w-4 h-4 accent-[#8C1515]"}),(0,a.jsx)("span",{className:"font-gothic text-xs text-gray-400",children:"Set as default address"})]}),(0,a.jsxs)("div",{className:"flex gap-3",children:[(0,a.jsx)("button",{type:"submit",className:"btn-luxury",children:"Save Address"}),(0,a.jsx)("button",{type:"button",onClick:()=>b(!1),className:"btn-outline",children:"Cancel"})]})]})]}),g?(0,a.jsx)("div",{className:"space-y-3",children:[1,2].map(e=>(0,a.jsx)("div",{className:"h-32 bg-[#111] animate-pulse rounded"},e))}):0!==s.length||y?(0,a.jsx)("div",{className:"space-y-4",children:s.map((e,t)=>(0,a.jsxs)(n.E.div,{initial:{opacity:0,y:10},animate:{opacity:1,y:0},transition:{delay:.05*t},className:"border border-white/10 p-6 relative hover:border-white/20 transition-colors",children:[e.isDefault&&(0,a.jsx)("span",{className:"absolute top-4 right-14 font-gothic text-[9px] tracking-[2px] uppercase text-[#8C1515]",children:"Default"}),(0,a.jsx)("button",{onClick:()=>C(e.id),className:"absolute top-4 right-4 text-gray-600 hover:text-[#8C1515] transition-colors",children:(0,a.jsx)(d.Z,{size:14})}),(0,a.jsx)("p",{className:"font-gothic text-sm text-white mb-1",children:e.name}),(0,a.jsxs)("p",{className:"font-gothic text-sm text-gray-500",children:[e.line1,e.line2?", ".concat(e.line2):""]}),(0,a.jsxs)("p",{className:"font-gothic text-sm text-gray-500",children:[e.city,", ",e.postalCode]}),(0,a.jsx)("p",{className:"font-gothic text-sm text-gray-500",children:e.country}),e.phone&&(0,a.jsx)("p",{className:"font-gothic text-sm text-gray-500 mt-1",children:e.phone})]},e.id))}):(0,a.jsxs)("div",{className:"text-center py-20 border border-white/5",children:[(0,a.jsx)(c.Z,{size:32,className:"text-gray-700 mx-auto mb-4"}),(0,a.jsx)("p",{className:"font-gothic text-gray-500 text-sm",children:"No addresses saved yet"})]})]})}):null}},8222:function(e,t,s){"use strict";var a=s(7541);let r=[{id:"seating",name:"Seating",slug:"seating"},{id:"objects",name:"Objects",slug:"objects"},{id:"lighting",name:"Lighting",slug:"lighting"}];function i(e){return Promise.resolve({data:e})}t.Z={get:e=>{if(e.startsWith("/products?featured")||e.startsWith("/products?"))return i({products:a.n6,pagination:{total:a.n6.length}});if(e.startsWith("/products/")){let t=e.replace("/products/","").split("?")[0],s=a.n6.find(e=>e.slug===t);return s?i(s):Promise.reject(Error("Not found"))}return"/categories"===e?i(r):"/collections"===e?i(a.jn):"/orders"===e||e.startsWith("/users/wishlist")||e.startsWith("/users/addresses")?i([]):i({})},post:(e,t)=>"/auth/login"===e?i({user:{id:"mock-user",name:"Guest User",email:(null==t?void 0:t.email)||"user@jodour.com",role:"USER"},accessToken:"mock-token"}):"/auth/register"===e?i({user:{id:"mock-user",name:(null==t?void 0:t.name)||"Guest User",email:(null==t?void 0:t.email)||"user@jodour.com",role:"USER"},accessToken:"mock-token"}):"/auth/logout"===e?i({}):"/auth/refresh"===e?Promise.reject(Error("No refresh")):"/messages"===e||"/newsletter"===e?i({success:!0}):"/users/addresses"===e?i({id:"mock-address"}):"/orders"===e?i({id:"mock-order",orderNumber:"JOD-"+Math.floor(9e4*Math.random()+1e4)}):e.startsWith("/payments/")?i({url:"/checkout/success"}):e.startsWith("/users/wishlist/")?i({added:!0}):i({}),put:(e,t)=>i({}),patch:(e,t)=>i({}),delete:e=>i({}),defaults:{headers:{common:{}}},interceptors:{request:{use:()=>{}},response:{use:()=>{}}}}},7541:function(e,t,s){"use strict";s.d(t,{OX:function(){return n},jn:function(){return o},n6:function(){return i}});let a="/assets/products";function r(e,t,s){return Array.from({length:t},(t,r)=>({id:"".concat(e,"-").concat(r+1),url:"".concat(a,"/").concat(e,"-").concat(r+1,".png"),alt:0===r?s:"".concat(s," view ").concat(r+1)}))}let i=[{id:"cloud",title:"Cloud",slug:"cloud",price:1890,comparePrice:2200,limited:!0,stock:12,featured:!0,description:"An sculptural office chair blending organic copper forms with textured upholstery — where Moroccan craftsmanship meets contemporary workspace design.",story:"Inspired by desert clouds and the soft curves of Atlas landscapes, Cloud reimagines the executive chair as a collectible design object.",images:r("cloud",6,"Cloud chair"),category:{name:"Seating",slug:"seating"},collection:{name:"Cloud Collection",slug:"cloud"},materials:[{id:"m1",name:"Copper"},{id:"m2",name:"Wool upholstery"}],dimensions:{width:65,height:120,depth:70,weight:18,unit:"cm"},reviews:[],_count:{reviews:0},related:[]},{id:"chelal",title:"Chelal",slug:"chelal",price:450,limited:!0,stock:24,featured:!0,description:"A luxury electric kettle adorned with traditional Moroccan filigree patterns in gold and bronze — heritage reimagined for the modern kitchen.",story:"Chelal draws from the ornate metalwork of Moroccan tea culture, transforming an everyday ritual into a moment of design.",images:r("chelal",4,"Chelal kettle"),category:{name:"Objects",slug:"objects"},collection:{name:"Chelal Collection",slug:"chelal"},materials:[{id:"m3",name:"Matte ceramic"},{id:"m4",name:"Gold filigree"}],dimensions:{width:22,height:28,depth:22,weight:1.8,unit:"cm"},reviews:[],_count:{reviews:0},related:[]},{id:"manara",title:"Manara",slug:"manara",price:680,limited:!0,stock:18,featured:!0,description:"Hammered copper table lamps with patterned ceramic bases — light as sculpture, rooted in Moroccan decorative tradition.",story:"Manara, meaning lighthouse, guides the eye through concentric copper rings that diffuse warm, ambient light.",images:r("manara",5,"Manara lamp"),category:{name:"Lighting",slug:"lighting"},collection:{name:"Manara Collection",slug:"manara"},materials:[{id:"m5",name:"Hammered copper"},{id:"m6",name:"Ceramic"}],dimensions:{width:35,height:55,depth:35,weight:3.2,unit:"cm"},reviews:[],_count:{reviews:0},related:[]}],o=[{id:"cloud",name:"Cloud",slug:"cloud",description:"Sculptural seating — copper and wool in organic harmony.",image:"".concat(a,"/cloud-1.png"),featured:!0,_count:{products:1}},{id:"chelal",name:"Chelal",slug:"chelal",description:"Moroccan filigree meets modern kitchen ritual.",image:"".concat(a,"/chelal-1.png"),featured:!0,_count:{products:1}},{id:"manara",name:"Manara",slug:"manara",description:"Hammered copper lighting — light as collectible art.",image:"".concat(a,"/manara-1.png"),featured:!0,_count:{products:1}}];function n(e){let t=i.find(t=>t.slug===e);if(!t)return null;let s=i.filter(t=>t.slug!==e).map(e=>({id:e.id,title:e.title,price:e.price,slug:e.slug,images:e.images}));return{...t,related:s}}},8228:function(e,t,s){"use strict";s.d(t,{useAuthStore:function(){return o}});var a=s(4660),r=s(4810),i=s(8222);let o=(0,a.Ue)()((0,r.tJ)(e=>({user:null,accessToken:null,isLoading:!1,login:async(t,s)=>{e({isLoading:!0}),await new Promise(e=>setTimeout(e,600));try{let a=await i.Z.post("/auth/login",{email:t,password:s});e({user:a.data.user,accessToken:a.data.accessToken,isLoading:!1})}catch(t){throw e({isLoading:!1}),Error("Login failed")}},register:async(t,s,a)=>{e({isLoading:!0}),await new Promise(e=>setTimeout(e,600));try{let a=await i.Z.post("/auth/register",{name:t,email:s});e({user:a.data.user,accessToken:a.data.accessToken,isLoading:!1})}catch(t){throw e({isLoading:!1}),Error("Registration failed")}},logout:async()=>{e({user:null,accessToken:null})},refreshToken:async()=>!1,setUser:t=>e({user:t}),setToken:t=>e({accessToken:t})}),{name:"jodour-auth",partialize:e=>({user:e.user,accessToken:e.accessToken})}))},4033:function(e,t,s){e.exports=s(5313)},5925:function(e,t,s){"use strict";let a,r;s.r(t),s.d(t,{CheckmarkIcon:function(){return Y},ErrorIcon:function(){return G},LoaderIcon:function(){return B},ToastBar:function(){return el},ToastIcon:function(){return es},Toaster:function(){return ep},default:function(){return em},resolveValue:function(){return N},toast:function(){return H},useToaster:function(){return F},useToasterStore:function(){return I}});var i,o=s(2265);let n={data:""},l=e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||n},c=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,d=/\/\*[^]*?\*\/|  +/g,u=/\n+/g,p=(e,t)=>{let s="",a="",r="";for(let i in e){let o=e[i];"@"==i[0]?"i"==i[1]?s=i+" "+o+";":a+="f"==i[1]?p(o,i):i+"{"+p(o,"k"==i[1]?"":t)+"}":"object"==typeof o?a+=p(o,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=o&&(i="-"==i[1]?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),r+=p.p?p.p(i,o):i+":"+o+";")}return s+(t&&r?t+"{"+r+"}":r)+a},m={},h=e=>{if("object"==typeof e){let t="";for(let s in e)t+=s+h(e[s]);return t}return e},f=(e,t,s,a,r)=>{var i;let o=h(e),n=m[o]||(m[o]=(e=>{let t=0,s=11;for(;t<e.length;)s=101*s+e.charCodeAt(t++)>>>0;return"go"+s})(o));if(!m[n]){let t=o!==e?e:(e=>{let t,s,a=[{}];for(;t=c.exec(e.replace(d,""));)t[4]?a.shift():t[3]?(s=t[3].replace(u," ").trim(),a.unshift(a[0][s]=a[0][s]||{})):a[0][t[1]]=t[2].replace(u," ").trim();return a[0]})(e);m[n]=p(r?{["@keyframes "+n]:t}:t,s?"":"."+n)}let l=s&&m.g;return s&&(m.g=m[n]),i=m[n],l?t.data=t.data.replace(l,i):-1===t.data.indexOf(i)&&(t.data=a?i+t.data:t.data+i),n},g=(e,t,s)=>e.reduce((e,a,r)=>{let i=t[r];if(i&&i.call){let e=i(s),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":p(e,""):!1===e?"":e}return e+a+(null==i?"":i)},"");function x(e){let t=this||{},s=e.call?e(t.p):e;return f(s.unshift?s.raw?g(s,[].slice.call(arguments,1),t.p):s.reduce((e,s)=>Object.assign(e,s&&s.call?s(t.p):s),{}):s,l(t.target),t.g,t.o,t.k)}x.bind({g:1});let y,b,v,k=x.bind({k:1});function w(e,t){let s=this||{};return function(){let a=arguments;function r(i,o){let n=Object.assign({},i),l=n.className||r.className;s.p=Object.assign({theme:b&&b()},n),s.o=/go\d/.test(l),n.className=x.apply(s,a)+(l?" "+l:""),t&&(n.ref=o);let c=e;return e[0]&&(c=n.as||e,delete n.as),v&&c[0]&&v(n),y(c,n)}return t?t(r):r}}var j=e=>"function"==typeof e,N=(e,t)=>j(e)?e(t):e,C=(a=0,()=>(++a).toString()),E=()=>{if(void 0===r&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");r=!e||e.matches}return r},A="default",T=(e,t)=>{let{toastLimit:s}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,s)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:a}=t;return T(e,{type:e.toasts.find(e=>e.id===a.id)?1:0,toast:a});case 3:let{toastId:r}=t;return{...e,toasts:e.toasts.map(e=>e.id===r||void 0===r?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},M=[],O={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},S={},L=(e,t=A)=>{S[t]=T(S[t]||O,e),M.forEach(([e,s])=>{e===t&&s(S[t])})},P=e=>Object.keys(S).forEach(t=>L(e,t)),$=e=>Object.keys(S).find(t=>S[t].toasts.some(t=>t.id===e)),_=(e=A)=>t=>{L(t,e)},D={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},I=(e={},t=A)=>{let[s,a]=(0,o.useState)(S[t]||O),r=(0,o.useRef)(S[t]);(0,o.useEffect)(()=>(r.current!==S[t]&&a(S[t]),M.push([t,a]),()=>{let e=M.findIndex(([e])=>e===t);e>-1&&M.splice(e,1)}),[t]);let i=s.toasts.map(t=>{var s,a,r;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(s=e[t.type])?void 0:s.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(a=e[t.type])?void 0:a.duration)||(null==e?void 0:e.duration)||D[t.type],style:{...e.style,...null==(r=e[t.type])?void 0:r.style,...t.style}}});return{...s,toasts:i}},Z=(e,t="blank",s)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...s,id:(null==s?void 0:s.id)||C()}),z=e=>(t,s)=>{let a=Z(t,e,s);return _(a.toasterId||$(a.id))({type:2,toast:a}),a.id},H=(e,t)=>z("blank")(e,t);H.error=z("error"),H.success=z("success"),H.loading=z("loading"),H.custom=z("custom"),H.dismiss=(e,t)=>{let s={type:3,toastId:e};t?_(t)(s):P(s)},H.dismissAll=e=>H.dismiss(void 0,e),H.remove=(e,t)=>{let s={type:4,toastId:e};t?_(t)(s):P(s)},H.removeAll=e=>H.remove(void 0,e),H.promise=(e,t,s)=>{let a=H.loading(t.loading,{...s,...null==s?void 0:s.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let r=t.success?N(t.success,e):void 0;return r?H.success(r,{id:a,...s,...null==s?void 0:s.success}):H.dismiss(a),e}).catch(e=>{let r=t.error?N(t.error,e):void 0;r?H.error(r,{id:a,...s,...null==s?void 0:s.error}):H.dismiss(a)}),e};var q=1e3,F=(e,t="default")=>{let{toasts:s,pausedAt:a}=I(e,t),r=(0,o.useRef)(new Map).current,i=(0,o.useCallback)((e,t=q)=>{if(r.has(e))return;let s=setTimeout(()=>{r.delete(e),n({type:4,toastId:e})},t);r.set(e,s)},[]);(0,o.useEffect)(()=>{if(a)return;let e=Date.now(),r=s.map(s=>{if(s.duration===1/0)return;let a=(s.duration||0)+s.pauseDuration-(e-s.createdAt);if(a<0){s.visible&&H.dismiss(s.id);return}return setTimeout(()=>H.dismiss(s.id,t),a)});return()=>{r.forEach(e=>e&&clearTimeout(e))}},[s,a,t]);let n=(0,o.useCallback)(_(t),[t]),l=(0,o.useCallback)(()=>{n({type:5,time:Date.now()})},[n]),c=(0,o.useCallback)((e,t)=>{n({type:1,toast:{id:e,height:t}})},[n]),d=(0,o.useCallback)(()=>{a&&n({type:6,time:Date.now()})},[a,n]),u=(0,o.useCallback)((e,t)=>{let{reverseOrder:a=!1,gutter:r=8,defaultPosition:i}=t||{},o=s.filter(t=>(t.position||i)===(e.position||i)&&t.height),n=o.findIndex(t=>t.id===e.id),l=o.filter((e,t)=>t<n&&e.visible).length;return o.filter(e=>e.visible).slice(...a?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+r,0)},[s]);return(0,o.useEffect)(()=>{s.forEach(e=>{if(e.dismissed)i(e.id,e.removeDelay);else{let t=r.get(e.id);t&&(clearTimeout(t),r.delete(e.id))}})},[s,i]),{toasts:s,handlers:{updateHeight:c,startPause:l,endPause:d,calculateOffset:u}}},U=k`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,W=k`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,R=k`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,G=w("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${U} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${W} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${R} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,V=k`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,B=w("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${V} 1s linear infinite;
`,J=k`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,X=k`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,Y=w("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${J} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${X} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,K=w("div")`
  position: absolute;
`,Q=w("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,ee=k`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,et=w("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${ee} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,es=({toast:e})=>{let{icon:t,type:s,iconTheme:a}=e;return void 0!==t?"string"==typeof t?o.createElement(et,null,t):t:"blank"===s?null:o.createElement(Q,null,o.createElement(B,{...a}),"loading"!==s&&o.createElement(K,null,"error"===s?o.createElement(G,{...a}):o.createElement(Y,{...a})))},ea=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,er=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,ei=w("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,eo=w("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,en=(e,t)=>{let s=e.includes("top")?1:-1,[a,r]=E()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[ea(s),er(s)];return{animation:t?`${k(a)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${k(r)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},el=o.memo(({toast:e,position:t,style:s,children:a})=>{let r=e.height?en(e.position||t||"top-center",e.visible):{opacity:0},i=o.createElement(es,{toast:e}),n=o.createElement(eo,{...e.ariaProps},N(e.message,e));return o.createElement(ei,{className:e.className,style:{...r,...s,...e.style}},"function"==typeof a?a({icon:i,message:n}):o.createElement(o.Fragment,null,i,n))});i=o.createElement,p.p=void 0,y=i,b=void 0,v=void 0;var ec=({id:e,className:t,style:s,onHeightUpdate:a,children:r})=>{let i=o.useCallback(t=>{if(t){let s=()=>{a(e,t.getBoundingClientRect().height)};s(),new MutationObserver(s).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,a]);return o.createElement("div",{ref:i,className:t,style:s},r)},ed=(e,t)=>{let s=e.includes("top"),a=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:E()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(s?1:-1)}px)`,...s?{top:0}:{bottom:0},...a}},eu=x`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ep=({reverseOrder:e,position:t="top-center",toastOptions:s,gutter:a,children:r,toasterId:i,containerStyle:n,containerClassName:l})=>{let{toasts:c,handlers:d}=F(s,i);return o.createElement("div",{"data-rht-toaster":i||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...n},className:l,onMouseEnter:d.startPause,onMouseLeave:d.endPause},c.map(s=>{let i=s.position||t,n=ed(i,d.calculateOffset(s,{reverseOrder:e,gutter:a,defaultPosition:t}));return o.createElement(ec,{id:s.id,key:s.id,onHeightUpdate:d.updateHeight,className:s.visible?eu:"",style:n},"custom"===s.type?N(s.message,s):r?r(s):o.createElement(el,{toast:s,position:i}))}))},em=H}},function(e){e.O(0,[4581,1396,5166,1865,2971,4938,1744],function(){return e(e.s=8816)}),_N_E=e.O()}]);