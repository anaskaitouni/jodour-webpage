(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[3455,8228],{2898:function(e,t,r){"use strict";r.d(t,{Z:function(){return o}});var a=r(2265),s={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase().trim(),o=(e,t)=>{let r=(0,a.forwardRef)(({color:r="currentColor",size:o=24,strokeWidth:n=2,absoluteStrokeWidth:l,className:c="",children:d,...u},m)=>(0,a.createElement)("svg",{ref:m,...s,width:o,height:o,stroke:r,strokeWidth:l?24*Number(n)/Number(o):n,className:["lucide",`lucide-${i(e)}`,c].join(" "),...u},[...t.map(([e,t])=>(0,a.createElement)(e,t)),...Array.isArray(d)?d:[d]]));return r.displayName=`${e}`,r}},7216:function(e,t,r){"use strict";r.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(2898).Z)("EyeOff",[["path",{d:"M9.88 9.88a3 3 0 1 0 4.24 4.24",key:"1jxqfv"}],["path",{d:"M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68",key:"9wicm4"}],["path",{d:"M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61",key:"1jreej"}],["line",{x1:"2",x2:"22",y1:"2",y2:"22",key:"a6p6uj"}]])},9670:function(e,t,r){"use strict";r.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(2898).Z)("Eye",[["path",{d:"M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z",key:"rwhkz3"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},5081:function(e,t,r){Promise.resolve().then(r.bind(r,6938))},6938:function(e,t,r){"use strict";r.r(t),r.d(t,{default:function(){return x}});var a=r(7437),s=r(2265),i=r(1396),o=r.n(i),n=r(1865),l=r(8110),c=r(2160),d=r(5925),u=r(7216),m=r(9670),p=r(8228),f=r(4033),h=r(8222);let g=c.Ry({name:c.Z_().min(2),phone:c.Z_().optional()}),y=c.Ry({currentPassword:c.Z_().min(1),newPassword:c.Z_().min(8).regex(/[A-Z]/).regex(/[0-9]/),confirmPassword:c.Z_()}).refine(e=>e.newPassword===e.confirmPassword,{message:"Passwords do not match",path:["confirmPassword"]});function x(){let{user:e,setUser:t}=(0,p.useAuthStore)(),r=(0,f.useRouter)(),[i,c]=(0,s.useState)(!1),[x,b]=(0,s.useState)(!1),[w,v]=(0,s.useState)(!1),[k,j]=(0,s.useState)(!1);if(!e)return r.push("/auth/login"),null;let N=(0,n.cI)({resolver:(0,l.F)(g),defaultValues:{name:e.name,phone:e.phone||""}}),C=(0,n.cI)({resolver:(0,l.F)(y)}),P=async r=>{v(!0);try{let a=await h.Z.patch("/users/profile",r);t({...e,...a.data}),d.default.success("Profile updated")}catch(e){d.default.error("Failed to update profile")}finally{v(!1)}},E=async e=>{j(!0);try{await h.Z.patch("/users/change-password",{currentPassword:e.currentPassword,newPassword:e.newPassword}),d.default.success("Password changed successfully"),C.reset()}catch(e){var t,r;d.default.error((null===(r=e.response)||void 0===r?void 0:null===(t=r.data)||void 0===t?void 0:t.error)||"Failed to change password")}finally{j(!1)}};return(0,a.jsx)("div",{className:"min-h-screen pt-24 px-[var(--gutter)] py-12",children:(0,a.jsxs)("div",{className:"max-w-2xl",children:[(0,a.jsxs)("div",{className:"flex items-center gap-3 mb-10",children:[(0,a.jsx)(o(),{href:"/dashboard",className:"font-gothic text-xs text-gray-500 hover:text-white",children:"Account"}),(0,a.jsx)("span",{className:"text-gray-700",children:"/"}),(0,a.jsx)("h1",{className:"font-gothic text-2xl font-light",children:"Settings"})]}),(0,a.jsxs)("div",{className:"mb-12",children:[(0,a.jsx)("h2",{className:"font-gothic text-[11px] tracking-[3px] uppercase text-gray-400 mb-6",children:"Profile Information"}),(0,a.jsxs)("form",{onSubmit:N.handleSubmit(P),className:"space-y-6",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Full Name"}),(0,a.jsx)("input",{...N.register("name"),className:"input-luxury"}),N.formState.errors.name&&(0,a.jsx)("p",{className:"font-gothic text-[10px] text-[#8C1515] mt-1",children:N.formState.errors.name.message})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Email"}),(0,a.jsx)("input",{value:e.email,disabled:!0,className:"input-luxury opacity-40 cursor-not-allowed"})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Phone"}),(0,a.jsx)("input",{...N.register("phone"),className:"input-luxury",placeholder:"+1 234 567 8900"})]}),(0,a.jsx)("button",{type:"submit",disabled:w,className:"btn-luxury disabled:opacity-50",children:w?"Saving...":"Save Changes"})]})]}),(0,a.jsx)("div",{className:"divider-red mb-12"}),(0,a.jsxs)("div",{children:[(0,a.jsx)("h2",{className:"font-gothic text-[11px] tracking-[3px] uppercase text-gray-400 mb-6",children:"Change Password"}),(0,a.jsxs)("form",{onSubmit:C.handleSubmit(E),className:"space-y-6",children:[(0,a.jsxs)("div",{className:"relative",children:[(0,a.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Current Password"}),(0,a.jsx)("input",{...C.register("currentPassword"),type:i?"text":"password",className:"input-luxury pr-10"}),(0,a.jsx)("button",{type:"button",onClick:()=>c(!i),className:"absolute right-0 top-8 text-gray-500",children:i?(0,a.jsx)(u.Z,{size:16}):(0,a.jsx)(m.Z,{size:16})}),C.formState.errors.currentPassword&&(0,a.jsx)("p",{className:"font-gothic text-[10px] text-[#8C1515] mt-1",children:"Required"})]}),(0,a.jsxs)("div",{className:"relative",children:[(0,a.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"New Password"}),(0,a.jsx)("input",{...C.register("newPassword"),type:x?"text":"password",className:"input-luxury pr-10"}),(0,a.jsx)("button",{type:"button",onClick:()=>b(!x),className:"absolute right-0 top-8 text-gray-500",children:x?(0,a.jsx)(u.Z,{size:16}):(0,a.jsx)(m.Z,{size:16})}),C.formState.errors.newPassword&&(0,a.jsx)("p",{className:"font-gothic text-[10px] text-[#8C1515] mt-1",children:C.formState.errors.newPassword.message})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{className:"font-gothic text-[10px] tracking-[2px] uppercase text-gray-500 block mb-2",children:"Confirm New Password"}),(0,a.jsx)("input",{...C.register("confirmPassword"),type:"password",className:"input-luxury"}),C.formState.errors.confirmPassword&&(0,a.jsx)("p",{className:"font-gothic text-[10px] text-[#8C1515] mt-1",children:C.formState.errors.confirmPassword.message})]}),(0,a.jsx)("button",{type:"submit",disabled:k,className:"btn-luxury disabled:opacity-50",children:k?"Changing...":"Change Password"})]})]})]})})}},8222:function(e,t,r){"use strict";var a=r(7541);let s=[{id:"seating",name:"Seating",slug:"seating"},{id:"objects",name:"Objects",slug:"objects"},{id:"lighting",name:"Lighting",slug:"lighting"}];function i(e){return Promise.resolve({data:e})}t.Z={get:e=>{if(e.startsWith("/products?featured")||e.startsWith("/products?"))return i({products:a.n6,pagination:{total:a.n6.length}});if(e.startsWith("/products/")){let t=e.replace("/products/","").split("?")[0],r=a.n6.find(e=>e.slug===t);return r?i(r):Promise.reject(Error("Not found"))}return"/categories"===e?i(s):"/collections"===e?i(a.jn):"/orders"===e||e.startsWith("/users/wishlist")||e.startsWith("/users/addresses")?i([]):i({})},post:(e,t)=>"/auth/login"===e?i({user:{id:"mock-user",name:"Guest User",email:(null==t?void 0:t.email)||"user@jodour.com",role:"USER"},accessToken:"mock-token"}):"/auth/register"===e?i({user:{id:"mock-user",name:(null==t?void 0:t.name)||"Guest User",email:(null==t?void 0:t.email)||"user@jodour.com",role:"USER"},accessToken:"mock-token"}):"/auth/logout"===e?i({}):"/auth/refresh"===e?Promise.reject(Error("No refresh")):"/messages"===e||"/newsletter"===e?i({success:!0}):"/users/addresses"===e?i({id:"mock-address"}):"/orders"===e?i({id:"mock-order",orderNumber:"JOD-"+Math.floor(9e4*Math.random()+1e4)}):e.startsWith("/payments/")?i({url:"/checkout/success"}):e.startsWith("/users/wishlist/")?i({added:!0}):i({}),put:(e,t)=>i({}),patch:(e,t)=>i({}),delete:e=>i({}),defaults:{headers:{common:{}}},interceptors:{request:{use:()=>{}},response:{use:()=>{}}}}},7541:function(e,t,r){"use strict";r.d(t,{OX:function(){return n},jn:function(){return o},n6:function(){return i}});let a="/assets/products";function s(e,t,r){return Array.from({length:t},(t,s)=>({id:"".concat(e,"-").concat(s+1),url:"".concat(a,"/").concat(e,"-").concat(s+1,".png"),alt:0===s?r:"".concat(r," view ").concat(s+1)}))}let i=[{id:"cloud",title:"Cloud",slug:"cloud",price:1890,comparePrice:2200,limited:!0,stock:12,featured:!0,description:"An sculptural office chair blending organic copper forms with textured upholstery — where Moroccan craftsmanship meets contemporary workspace design.",story:"Inspired by desert clouds and the soft curves of Atlas landscapes, Cloud reimagines the executive chair as a collectible design object.",images:s("cloud",6,"Cloud chair"),category:{name:"Seating",slug:"seating"},collection:{name:"Cloud Collection",slug:"cloud"},materials:[{id:"m1",name:"Copper"},{id:"m2",name:"Wool upholstery"}],dimensions:{width:65,height:120,depth:70,weight:18,unit:"cm"},reviews:[],_count:{reviews:0},related:[]},{id:"chelal",title:"Chelal",slug:"chelal",price:450,limited:!0,stock:24,featured:!0,description:"A luxury electric kettle adorned with traditional Moroccan filigree patterns in gold and bronze — heritage reimagined for the modern kitchen.",story:"Chelal draws from the ornate metalwork of Moroccan tea culture, transforming an everyday ritual into a moment of design.",images:s("chelal",4,"Chelal kettle"),category:{name:"Objects",slug:"objects"},collection:{name:"Chelal Collection",slug:"chelal"},materials:[{id:"m3",name:"Matte ceramic"},{id:"m4",name:"Gold filigree"}],dimensions:{width:22,height:28,depth:22,weight:1.8,unit:"cm"},reviews:[],_count:{reviews:0},related:[]},{id:"manara",title:"Manara",slug:"manara",price:680,limited:!0,stock:18,featured:!0,description:"Hammered copper table lamps with patterned ceramic bases — light as sculpture, rooted in Moroccan decorative tradition.",story:"Manara, meaning lighthouse, guides the eye through concentric copper rings that diffuse warm, ambient light.",images:s("manara",5,"Manara lamp"),category:{name:"Lighting",slug:"lighting"},collection:{name:"Manara Collection",slug:"manara"},materials:[{id:"m5",name:"Hammered copper"},{id:"m6",name:"Ceramic"}],dimensions:{width:35,height:55,depth:35,weight:3.2,unit:"cm"},reviews:[],_count:{reviews:0},related:[]}],o=[{id:"cloud",name:"Cloud",slug:"cloud",description:"Sculptural seating — copper and wool in organic harmony.",image:"".concat(a,"/cloud-1.png"),featured:!0,_count:{products:1}},{id:"chelal",name:"Chelal",slug:"chelal",description:"Moroccan filigree meets modern kitchen ritual.",image:"".concat(a,"/chelal-1.png"),featured:!0,_count:{products:1}},{id:"manara",name:"Manara",slug:"manara",description:"Hammered copper lighting — light as collectible art.",image:"".concat(a,"/manara-1.png"),featured:!0,_count:{products:1}}];function n(e){let t=i.find(t=>t.slug===e);if(!t)return null;let r=i.filter(t=>t.slug!==e).map(e=>({id:e.id,title:e.title,price:e.price,slug:e.slug,images:e.images}));return{...t,related:r}}},8228:function(e,t,r){"use strict";r.d(t,{useAuthStore:function(){return o}});var a=r(4660),s=r(4810),i=r(8222);let o=(0,a.Ue)()((0,s.tJ)(e=>({user:null,accessToken:null,isLoading:!1,login:async(t,r)=>{e({isLoading:!0}),await new Promise(e=>setTimeout(e,600));try{let a=await i.Z.post("/auth/login",{email:t,password:r});e({user:a.data.user,accessToken:a.data.accessToken,isLoading:!1})}catch(t){throw e({isLoading:!1}),Error("Login failed")}},register:async(t,r,a)=>{e({isLoading:!0}),await new Promise(e=>setTimeout(e,600));try{let a=await i.Z.post("/auth/register",{name:t,email:r});e({user:a.data.user,accessToken:a.data.accessToken,isLoading:!1})}catch(t){throw e({isLoading:!1}),Error("Registration failed")}},logout:async()=>{e({user:null,accessToken:null})},refreshToken:async()=>!1,setUser:t=>e({user:t}),setToken:t=>e({accessToken:t})}),{name:"jodour-auth",partialize:e=>({user:e.user,accessToken:e.accessToken})}))},622:function(e,t,r){"use strict";var a=r(2265),s=Symbol.for("react.element"),i=Symbol.for("react.fragment"),o=Object.prototype.hasOwnProperty,n=a.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,l={key:!0,ref:!0,__self:!0,__source:!0};function c(e,t,r){var a,i={},c=null,d=null;for(a in void 0!==r&&(c=""+r),void 0!==t.key&&(c=""+t.key),void 0!==t.ref&&(d=t.ref),t)o.call(t,a)&&!l.hasOwnProperty(a)&&(i[a]=t[a]);if(e&&e.defaultProps)for(a in t=e.defaultProps)void 0===i[a]&&(i[a]=t[a]);return{$$typeof:s,type:e,key:c,ref:d,props:i,_owner:n.current}}t.Fragment=i,t.jsx=c,t.jsxs=c},7437:function(e,t,r){"use strict";e.exports=r(622)},4033:function(e,t,r){e.exports=r(5313)},5925:function(e,t,r){"use strict";let a,s;r.r(t),r.d(t,{CheckmarkIcon:function(){return X},ErrorIcon:function(){return B},LoaderIcon:function(){return J},ToastBar:function(){return el},ToastIcon:function(){return er},Toaster:function(){return em},default:function(){return ep},resolveValue:function(){return N},toast:function(){return R},useToaster:function(){return W},useToasterStore:function(){return I}});var i,o=r(2265);let n={data:""},l=e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||n},c=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,d=/\/\*[^]*?\*\/|  +/g,u=/\n+/g,m=(e,t)=>{let r="",a="",s="";for(let i in e){let o=e[i];"@"==i[0]?"i"==i[1]?r=i+" "+o+";":a+="f"==i[1]?m(o,i):i+"{"+m(o,"k"==i[1]?"":t)+"}":"object"==typeof o?a+=m(o,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=o&&(i="-"==i[1]?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),s+=m.p?m.p(i,o):i+":"+o+";")}return r+(t&&s?t+"{"+s+"}":s)+a},p={},f=e=>{if("object"==typeof e){let t="";for(let r in e)t+=r+f(e[r]);return t}return e},h=(e,t,r,a,s)=>{var i;let o=f(e),n=p[o]||(p[o]=(e=>{let t=0,r=11;for(;t<e.length;)r=101*r+e.charCodeAt(t++)>>>0;return"go"+r})(o));if(!p[n]){let t=o!==e?e:(e=>{let t,r,a=[{}];for(;t=c.exec(e.replace(d,""));)t[4]?a.shift():t[3]?(r=t[3].replace(u," ").trim(),a.unshift(a[0][r]=a[0][r]||{})):a[0][t[1]]=t[2].replace(u," ").trim();return a[0]})(e);p[n]=m(s?{["@keyframes "+n]:t}:t,r?"":"."+n)}let l=r&&p.g;return r&&(p.g=p[n]),i=p[n],l?t.data=t.data.replace(l,i):-1===t.data.indexOf(i)&&(t.data=a?i+t.data:t.data+i),n},g=(e,t,r)=>e.reduce((e,a,s)=>{let i=t[s];if(i&&i.call){let e=i(r),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":m(e,""):!1===e?"":e}return e+a+(null==i?"":i)},"");function y(e){let t=this||{},r=e.call?e(t.p):e;return h(r.unshift?r.raw?g(r,[].slice.call(arguments,1),t.p):r.reduce((e,r)=>Object.assign(e,r&&r.call?r(t.p):r),{}):r,l(t.target),t.g,t.o,t.k)}y.bind({g:1});let x,b,w,v=y.bind({k:1});function k(e,t){let r=this||{};return function(){let a=arguments;function s(i,o){let n=Object.assign({},i),l=n.className||s.className;r.p=Object.assign({theme:b&&b()},n),r.o=/go\d/.test(l),n.className=y.apply(r,a)+(l?" "+l:""),t&&(n.ref=o);let c=e;return e[0]&&(c=n.as||e,delete n.as),w&&c[0]&&w(n),x(c,n)}return t?t(s):s}}var j=e=>"function"==typeof e,N=(e,t)=>j(e)?e(t):e,C=(a=0,()=>(++a).toString()),P=()=>{if(void 0===s&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");s=!e||e.matches}return s},E="default",_=(e,t)=>{let{toastLimit:r}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,r)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:a}=t;return _(e,{type:e.toasts.find(e=>e.id===a.id)?1:0,toast:a});case 3:let{toastId:s}=t;return{...e,toasts:e.toasts.map(e=>e.id===s||void 0===s?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},S=[],O={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},T={},A=(e,t=E)=>{T[t]=_(T[t]||O,e),S.forEach(([e,r])=>{e===t&&r(T[t])})},$=e=>Object.keys(T).forEach(t=>A(e,t)),L=e=>Object.keys(T).find(t=>T[t].toasts.some(t=>t.id===e)),M=(e=E)=>t=>{A(t,e)},Z={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},I=(e={},t=E)=>{let[r,a]=(0,o.useState)(T[t]||O),s=(0,o.useRef)(T[t]);(0,o.useEffect)(()=>(s.current!==T[t]&&a(T[t]),S.push([t,a]),()=>{let e=S.findIndex(([e])=>e===t);e>-1&&S.splice(e,1)}),[t]);let i=r.toasts.map(t=>{var r,a,s;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(r=e[t.type])?void 0:r.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(a=e[t.type])?void 0:a.duration)||(null==e?void 0:e.duration)||Z[t.type],style:{...e.style,...null==(s=e[t.type])?void 0:s.style,...t.style}}});return{...r,toasts:i}},z=(e,t="blank",r)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...r,id:(null==r?void 0:r.id)||C()}),D=e=>(t,r)=>{let a=z(t,e,r);return M(a.toasterId||L(a.id))({type:2,toast:a}),a.id},R=(e,t)=>D("blank")(e,t);R.error=D("error"),R.success=D("success"),R.loading=D("loading"),R.custom=D("custom"),R.dismiss=(e,t)=>{let r={type:3,toastId:e};t?M(t)(r):$(r)},R.dismissAll=e=>R.dismiss(void 0,e),R.remove=(e,t)=>{let r={type:4,toastId:e};t?M(t)(r):$(r)},R.removeAll=e=>R.remove(void 0,e),R.promise=(e,t,r)=>{let a=R.loading(t.loading,{...r,...null==r?void 0:r.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let s=t.success?N(t.success,e):void 0;return s?R.success(s,{id:a,...r,...null==r?void 0:r.success}):R.dismiss(a),e}).catch(e=>{let s=t.error?N(t.error,e):void 0;s?R.error(s,{id:a,...r,...null==r?void 0:r.error}):R.dismiss(a)}),e};var F=1e3,W=(e,t="default")=>{let{toasts:r,pausedAt:a}=I(e,t),s=(0,o.useRef)(new Map).current,i=(0,o.useCallback)((e,t=F)=>{if(s.has(e))return;let r=setTimeout(()=>{s.delete(e),n({type:4,toastId:e})},t);s.set(e,r)},[]);(0,o.useEffect)(()=>{if(a)return;let e=Date.now(),s=r.map(r=>{if(r.duration===1/0)return;let a=(r.duration||0)+r.pauseDuration-(e-r.createdAt);if(a<0){r.visible&&R.dismiss(r.id);return}return setTimeout(()=>R.dismiss(r.id,t),a)});return()=>{s.forEach(e=>e&&clearTimeout(e))}},[r,a,t]);let n=(0,o.useCallback)(M(t),[t]),l=(0,o.useCallback)(()=>{n({type:5,time:Date.now()})},[n]),c=(0,o.useCallback)((e,t)=>{n({type:1,toast:{id:e,height:t}})},[n]),d=(0,o.useCallback)(()=>{a&&n({type:6,time:Date.now()})},[a,n]),u=(0,o.useCallback)((e,t)=>{let{reverseOrder:a=!1,gutter:s=8,defaultPosition:i}=t||{},o=r.filter(t=>(t.position||i)===(e.position||i)&&t.height),n=o.findIndex(t=>t.id===e.id),l=o.filter((e,t)=>t<n&&e.visible).length;return o.filter(e=>e.visible).slice(...a?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+s,0)},[r]);return(0,o.useEffect)(()=>{r.forEach(e=>{if(e.dismissed)i(e.id,e.removeDelay);else{let t=s.get(e.id);t&&(clearTimeout(t),s.delete(e.id))}})},[r,i]),{toasts:r,handlers:{updateHeight:c,startPause:l,endPause:d,calculateOffset:u}}},U=v`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,H=v`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,q=v`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,B=k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${U} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${H} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${q} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,G=v`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,J=k("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${G} 1s linear infinite;
`,V=v`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,Y=v`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,X=k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${V} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${Y} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,K=k("div")`
  position: absolute;
`,Q=k("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,ee=v`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,et=k("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${ee} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,er=({toast:e})=>{let{icon:t,type:r,iconTheme:a}=e;return void 0!==t?"string"==typeof t?o.createElement(et,null,t):t:"blank"===r?null:o.createElement(Q,null,o.createElement(J,{...a}),"loading"!==r&&o.createElement(K,null,"error"===r?o.createElement(B,{...a}):o.createElement(X,{...a})))},ea=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,es=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,ei=k("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,eo=k("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,en=(e,t)=>{let r=e.includes("top")?1:-1,[a,s]=P()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[ea(r),es(r)];return{animation:t?`${v(a)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${v(s)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},el=o.memo(({toast:e,position:t,style:r,children:a})=>{let s=e.height?en(e.position||t||"top-center",e.visible):{opacity:0},i=o.createElement(er,{toast:e}),n=o.createElement(eo,{...e.ariaProps},N(e.message,e));return o.createElement(ei,{className:e.className,style:{...s,...r,...e.style}},"function"==typeof a?a({icon:i,message:n}):o.createElement(o.Fragment,null,i,n))});i=o.createElement,m.p=void 0,x=i,b=void 0,w=void 0;var ec=({id:e,className:t,style:r,onHeightUpdate:a,children:s})=>{let i=o.useCallback(t=>{if(t){let r=()=>{a(e,t.getBoundingClientRect().height)};r(),new MutationObserver(r).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,a]);return o.createElement("div",{ref:i,className:t,style:r},s)},ed=(e,t)=>{let r=e.includes("top"),a=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:P()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(r?1:-1)}px)`,...r?{top:0}:{bottom:0},...a}},eu=y`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,em=({reverseOrder:e,position:t="top-center",toastOptions:r,gutter:a,children:s,toasterId:i,containerStyle:n,containerClassName:l})=>{let{toasts:c,handlers:d}=W(r,i);return o.createElement("div",{"data-rht-toaster":i||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...n},className:l,onMouseEnter:d.startPause,onMouseLeave:d.endPause},c.map(r=>{let i=r.position||t,n=ed(i,d.calculateOffset(r,{reverseOrder:e,gutter:a,defaultPosition:t}));return o.createElement(ec,{id:r.id,key:r.id,onHeightUpdate:d.updateHeight,className:r.visible?eu:"",style:n},"custom"===r.type?N(r.message,r):s?s(r):o.createElement(el,{toast:r,position:i}))}))},ep=R}},function(e){e.O(0,[1396,5166,1865,9727,2971,4938,1744],function(){return e(e.s=5081)}),_N_E=e.O()}]);