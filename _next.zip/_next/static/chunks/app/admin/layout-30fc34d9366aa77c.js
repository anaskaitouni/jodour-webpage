(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[9091],{2898:function(e,t,r){"use strict";r.d(t,{Z:function(){return a}});var n=r(2265),s={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase().trim(),a=(e,t)=>{let r=(0,n.forwardRef)(({color:r="currentColor",size:a=24,strokeWidth:o=2,absoluteStrokeWidth:c,className:l="",children:h,...u},d)=>(0,n.createElement)("svg",{ref:d,...s,width:a,height:a,stroke:r,strokeWidth:c?24*Number(o)/Number(a):o,className:["lucide",`lucide-${i(e)}`,l].join(" "),...u},[...t.map(([e,t])=>(0,n.createElement)(e,t)),...Array.isArray(h)?h:[h]]));return r.displayName=`${e}`,r}},6637:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(2898).Z)("FileText",[["path",{d:"M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z",key:"1nnpy2"}],["polyline",{points:"14 2 14 8 20 8",key:"1ew0cm"}],["line",{x1:"16",x2:"8",y1:"13",y2:"13",key:"14keom"}],["line",{x1:"16",x2:"8",y1:"17",y2:"17",key:"17nazh"}],["line",{x1:"10",x2:"8",y1:"9",y2:"9",key:"1a5vjj"}]])},3167:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(2898).Z)("FolderOpen",[["path",{d:"m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",key:"usdka0"}]])},5119:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(2898).Z)("LayoutDashboard",[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]])},2882:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(2898).Z)("MessageSquare",[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",key:"1lielz"}]])},4322:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(2898).Z)("Package",[["path",{d:"m7.5 4.27 9 5.15",key:"1c824w"}],["path",{d:"M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z",key:"hh9hay"}],["path",{d:"m3.3 7 8.7 5 8.7-5",key:"g66t2b"}],["path",{d:"M12 22V12",key:"d0xqtd"}]])},3505:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(2898).Z)("ShoppingCart",[["circle",{cx:"8",cy:"21",r:"1",key:"jimo8o"}],["circle",{cx:"19",cy:"21",r:"1",key:"13723u"}],["path",{d:"M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12",key:"9zh506"}]])},4871:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(2898).Z)("Tags",[["path",{d:"M9 5H2v7l6.29 6.29c.94.94 2.48.94 3.42 0l3.58-3.58c.94-.94.94-2.48 0-3.42L9 5Z",key:"gt587u"}],["path",{d:"M6 9.01V9",key:"1flxpt"}],["path",{d:"m15 5 6.3 6.3a2.4 2.4 0 0 1 0 3.4L17 19",key:"1cbfv1"}]])},5750:function(e,t,r){"use strict";r.d(t,{Z:function(){return n}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r(2898).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},8488:function(e,t,r){Promise.resolve().then(r.bind(r,4579))},4579:function(e,t,r){"use strict";r.r(t),r.d(t,{default:function(){return v}});var n=r(7437),s=r(2265),i=r(4033),a=r(1396),o=r.n(a),c=r(5119),l=r(4322),h=r(3167),u=r(4871),d=r(3505),f=r(5750),x=r(2882),p=r(6637),y=r(5883),m=r(8228),g=r(5925);let k=[{href:"/admin",label:"Dashboard",icon:c.Z},{href:"/admin/products",label:"Products",icon:l.Z},{href:"/admin/collections",label:"Collections",icon:h.Z},{href:"/admin/categories",label:"Categories",icon:u.Z},{href:"/admin/orders",label:"Orders",icon:d.Z},{href:"/admin/users",label:"Users",icon:f.Z},{href:"/admin/messages",label:"Messages",icon:x.Z},{href:"/admin/blog",label:"Blog",icon:p.Z}];function v(e){let{children:t}=e,{user:r,logout:a}=(0,m.useAuthStore)(),c=(0,i.useRouter)(),l=(0,i.usePathname)();(0,s.useEffect)(()=>{if(!r){c.push("/auth/login");return}"ADMIN"!==r.role&&c.push("/")},[r,c]);let h=async()=>{await a(),c.push("/"),g.default.success("Logged out")};return r&&"ADMIN"===r.role?(0,n.jsxs)("div",{className:"min-h-screen flex bg-[#050505]",children:[(0,n.jsxs)("div",{className:"w-64 flex-shrink-0 bg-[#080808] border-r border-white/5 flex flex-col fixed left-0 top-0 bottom-0 z-50",children:[(0,n.jsxs)("div",{className:"p-6 border-b border-white/5",children:[(0,n.jsxs)(o(),{href:"/",className:"font-gothic text-lg tracking-[4px] uppercase",children:["JODOUR ",(0,n.jsx)("span",{className:"text-[#8C1515]",children:"—"})]}),(0,n.jsx)("p",{className:"font-gothic text-[9px] tracking-[3px] uppercase text-gray-600 mt-1",children:"Admin Panel"})]}),(0,n.jsx)("nav",{className:"flex-1 p-4 space-y-1 overflow-y-auto",children:k.map(e=>{let{href:t,label:r,icon:s}=e,i=l===t||"/admin"!==t&&l.startsWith(t);return(0,n.jsxs)(o(),{href:t,className:"flex items-center gap-3 px-4 py-2.5 font-gothic text-xs tracking-wide transition-colors rounded group ".concat(i?"bg-white/5 text-white":"text-gray-500 hover:text-white hover:bg-white/[0.03]"),children:[(0,n.jsx)(s,{size:14,className:i?"text-[#8C1515]":"group-hover:text-[#8C1515] transition-colors"}),r]},t)})}),(0,n.jsxs)("div",{className:"p-4 border-t border-white/5",children:[(0,n.jsxs)("div",{className:"flex items-center gap-3 px-4 py-2 mb-2",children:[(0,n.jsx)("div",{className:"w-7 h-7 bg-[#8C1515] rounded-full flex items-center justify-center flex-shrink-0",children:(0,n.jsx)("span",{className:"font-gothic text-xs",children:r.name[0]})}),(0,n.jsxs)("div",{className:"overflow-hidden",children:[(0,n.jsx)("p",{className:"font-gothic text-xs text-white truncate",children:r.name}),(0,n.jsx)("p",{className:"font-gothic text-[9px] text-gray-600 truncate",children:r.email})]})]}),(0,n.jsxs)("button",{onClick:h,className:"w-full flex items-center gap-3 px-4 py-2.5 font-gothic text-xs text-gray-500 hover:text-white transition-colors rounded hover:bg-white/5",children:[(0,n.jsx)(y.Z,{size:13})," Sign Out"]})]})]}),(0,n.jsx)("div",{className:"flex-1 ml-64 overflow-auto",children:t})]}):null}},622:function(e,t,r){"use strict";var n=r(2265),s=Symbol.for("react.element"),i=Symbol.for("react.fragment"),a=Object.prototype.hasOwnProperty,o=n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,c={key:!0,ref:!0,__self:!0,__source:!0};function l(e,t,r){var n,i={},l=null,h=null;for(n in void 0!==r&&(l=""+r),void 0!==t.key&&(l=""+t.key),void 0!==t.ref&&(h=t.ref),t)a.call(t,n)&&!c.hasOwnProperty(n)&&(i[n]=t[n]);if(e&&e.defaultProps)for(n in t=e.defaultProps)void 0===i[n]&&(i[n]=t[n]);return{$$typeof:s,type:e,key:l,ref:h,props:i,_owner:o.current}}t.Fragment=i,t.jsx=l,t.jsxs=l},7437:function(e,t,r){"use strict";e.exports=r(622)}},function(e){e.O(0,[1396,5166,8728,2971,4938,1744],function(){return e(e.s=8488)}),_N_E=e.O()}]);