(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[8454],{8291:function(e,t,a){"use strict";a.d(t,{Z:function(){return s}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(2898).Z)("ArrowRight",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]])},7216:function(e,t,a){"use strict";a.d(t,{Z:function(){return s}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(2898).Z)("EyeOff",[["path",{d:"M9.88 9.88a3 3 0 1 0 4.24 4.24",key:"1jxqfv"}],["path",{d:"M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68",key:"9wicm4"}],["path",{d:"M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61",key:"1jreej"}],["line",{x1:"2",x2:"22",y1:"2",y2:"22",key:"a6p6uj"}]])},9670:function(e,t,a){"use strict";a.d(t,{Z:function(){return s}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a(2898).Z)("Eye",[["path",{d:"M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z",key:"rwhkz3"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},4586:function(e,t,a){Promise.resolve().then(a.bind(a,9432))},9432:function(e,t,a){"use strict";a.r(t),a.d(t,{default:function(){return x}});var s=a(7437),r=a(2265),i=a(4033),o=a(1396),n=a.n(o),l=a(5251),c=a(1865),d=a(8110),u=a(2160),p=a(5925),m=a(7216),f=a(9670),h=a(8291);let y=u.Ry({name:u.Z_().min(2,"Name must be at least 2 characters"),email:u.Z_().email("Valid email required"),password:u.Z_().min(8,"Password must be at least 8 characters").regex(/[A-Z]/,"Password must contain an uppercase letter").regex(/[0-9]/,"Password must contain a number"),confirmPassword:u.Z_()}).refine(e=>e.password===e.confirmPassword,{message:"Passwords do not match",path:["confirmPassword"]});function x(){let[e,t]=(0,r.useState)(!1),[o,u]=(0,r.useState)(!1),x=(0,i.useRouter)(),{register:g,handleSubmit:b,formState:{errors:v}}=(0,c.cI)({resolver:(0,d.F)(y)}),w=async e=>{u(!0),await new Promise(e=>setTimeout(e,700));try{let{useAuthStore:t}=await Promise.all([a.e(5166),a.e(8228)]).then(a.bind(a,8228)),s=t.getState();s.register&&await s.register(e.name,e.email,e.password),x.push("/dashboard")}catch(e){p.default.error("Registration failed")}finally{u(!1)}};return(0,s.jsx)("div",{className:"min-h-screen flex items-center justify-center p-8",children:(0,s.jsxs)(l.E.div,{className:"w-full max-w-md",initial:{opacity:0,y:30},animate:{opacity:1,y:0},transition:{duration:.8},children:[(0,s.jsx)("div",{className:"mb-12",children:(0,s.jsxs)(n(),{href:"/",className:"font-gothic text-2xl tracking-[6px] uppercase",children:["JODOUR ",(0,s.jsx)("span",{className:"text-[#8C1515]",children:"—"})]})}),(0,s.jsx)("h1",{className:"font-gothic text-3xl font-light mb-2",children:"Create Account"}),(0,s.jsx)("p",{className:"font-gothic text-sm text-gray-500 mb-10",children:"Join the JODOUR community"}),(0,s.jsxs)("form",{onSubmit:b(w),className:"space-y-8",children:[(0,s.jsxs)("div",{children:[(0,s.jsx)("input",{...g("name"),placeholder:"Full Name",className:"input-luxury"}),v.name&&(0,s.jsx)("p",{className:"font-gothic text-[10px] text-[#8C1515] mt-1",children:v.name.message})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)("input",{...g("email"),type:"email",placeholder:"Email Address",className:"input-luxury"}),v.email&&(0,s.jsx)("p",{className:"font-gothic text-[10px] text-[#8C1515] mt-1",children:v.email.message})]}),(0,s.jsxs)("div",{className:"relative",children:[(0,s.jsx)("input",{...g("password"),type:e?"text":"password",placeholder:"Password",className:"input-luxury pr-10"}),(0,s.jsx)("button",{type:"button",onClick:()=>t(!e),className:"absolute right-0 top-1/2 -translate-y-1/2 text-gray-500",children:e?(0,s.jsx)(m.Z,{size:16}):(0,s.jsx)(f.Z,{size:16})}),v.password&&(0,s.jsx)("p",{className:"font-gothic text-[10px] text-[#8C1515] mt-1",children:v.password.message})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)("input",{...g("confirmPassword"),type:"password",placeholder:"Confirm Password",className:"input-luxury"}),v.confirmPassword&&(0,s.jsx)("p",{className:"font-gothic text-[10px] text-[#8C1515] mt-1",children:v.confirmPassword.message})]}),(0,s.jsxs)("button",{type:"submit",disabled:o,className:"btn-luxury w-full justify-center disabled:opacity-50",children:[o?"Creating Account...":"Create Account"," ",(0,s.jsx)(h.Z,{size:14})]})]}),(0,s.jsxs)("p",{className:"font-gothic text-sm text-gray-500 text-center mt-8",children:["Already have an account?"," ",(0,s.jsx)(n(),{href:"/auth/login",className:"text-white hover:text-[#8C1515] transition-colors",children:"Sign in"})]})]})})}},4033:function(e,t,a){e.exports=a(5313)},5925:function(e,t,a){"use strict";let s,r;a.r(t),a.d(t,{CheckmarkIcon:function(){return Q},ErrorIcon:function(){return B},LoaderIcon:function(){return Y},ToastBar:function(){return el},ToastIcon:function(){return ea},Toaster:function(){return ep},default:function(){return em},resolveValue:function(){return N},toast:function(){return F},useToaster:function(){return H},useToasterStore:function(){return T}});var i,o=a(2265);let n={data:""},l=e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||n},c=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,d=/\/\*[^]*?\*\/|  +/g,u=/\n+/g,p=(e,t)=>{let a="",s="",r="";for(let i in e){let o=e[i];"@"==i[0]?"i"==i[1]?a=i+" "+o+";":s+="f"==i[1]?p(o,i):i+"{"+p(o,"k"==i[1]?"":t)+"}":"object"==typeof o?s+=p(o,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=o&&(i="-"==i[1]?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),r+=p.p?p.p(i,o):i+":"+o+";")}return a+(t&&r?t+"{"+r+"}":r)+s},m={},f=e=>{if("object"==typeof e){let t="";for(let a in e)t+=a+f(e[a]);return t}return e},h=(e,t,a,s,r)=>{var i;let o=f(e),n=m[o]||(m[o]=(e=>{let t=0,a=11;for(;t<e.length;)a=101*a+e.charCodeAt(t++)>>>0;return"go"+a})(o));if(!m[n]){let t=o!==e?e:(e=>{let t,a,s=[{}];for(;t=c.exec(e.replace(d,""));)t[4]?s.shift():t[3]?(a=t[3].replace(u," ").trim(),s.unshift(s[0][a]=s[0][a]||{})):s[0][t[1]]=t[2].replace(u," ").trim();return s[0]})(e);m[n]=p(r?{["@keyframes "+n]:t}:t,a?"":"."+n)}let l=a&&m.g;return a&&(m.g=m[n]),i=m[n],l?t.data=t.data.replace(l,i):-1===t.data.indexOf(i)&&(t.data=s?i+t.data:t.data+i),n},y=(e,t,a)=>e.reduce((e,s,r)=>{let i=t[r];if(i&&i.call){let e=i(a),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":p(e,""):!1===e?"":e}return e+s+(null==i?"":i)},"");function x(e){let t=this||{},a=e.call?e(t.p):e;return h(a.unshift?a.raw?y(a,[].slice.call(arguments,1),t.p):a.reduce((e,a)=>Object.assign(e,a&&a.call?a(t.p):a),{}):a,l(t.target),t.g,t.o,t.k)}x.bind({g:1});let g,b,v,w=x.bind({k:1});function j(e,t){let a=this||{};return function(){let s=arguments;function r(i,o){let n=Object.assign({},i),l=n.className||r.className;a.p=Object.assign({theme:b&&b()},n),a.o=/go\d/.test(l),n.className=x.apply(a,s)+(l?" "+l:""),t&&(n.ref=o);let c=e;return e[0]&&(c=n.as||e,delete n.as),v&&c[0]&&v(n),g(c,n)}return t?t(r):r}}var k=e=>"function"==typeof e,N=(e,t)=>k(e)?e(t):e,E=(s=0,()=>(++s).toString()),C=()=>{if(void 0===r&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");r=!e||e.matches}return r},P="default",O=(e,t)=>{let{toastLimit:a}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,a)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:s}=t;return O(e,{type:e.toasts.find(e=>e.id===s.id)?1:0,toast:s});case 3:let{toastId:r}=t;return{...e,toasts:e.toasts.map(e=>e.id===r||void 0===r?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},A=[],$={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},_={},z=(e,t=P)=>{_[t]=O(_[t]||$,e),A.forEach(([e,a])=>{e===t&&a(_[t])})},D=e=>Object.keys(_).forEach(t=>z(e,t)),I=e=>Object.keys(_).find(t=>_[t].toasts.some(t=>t.id===e)),Z=(e=P)=>t=>{z(t,e)},S={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},T=(e={},t=P)=>{let[a,s]=(0,o.useState)(_[t]||$),r=(0,o.useRef)(_[t]);(0,o.useEffect)(()=>(r.current!==_[t]&&s(_[t]),A.push([t,s]),()=>{let e=A.findIndex(([e])=>e===t);e>-1&&A.splice(e,1)}),[t]);let i=a.toasts.map(t=>{var a,s,r;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(a=e[t.type])?void 0:a.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(s=e[t.type])?void 0:s.duration)||(null==e?void 0:e.duration)||S[t.type],style:{...e.style,...null==(r=e[t.type])?void 0:r.style,...t.style}}});return{...a,toasts:i}},M=(e,t="blank",a)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:(null==a?void 0:a.id)||E()}),R=e=>(t,a)=>{let s=M(t,e,a);return Z(s.toasterId||I(s.id))({type:2,toast:s}),s.id},F=(e,t)=>R("blank")(e,t);F.error=R("error"),F.success=R("success"),F.loading=R("loading"),F.custom=R("custom"),F.dismiss=(e,t)=>{let a={type:3,toastId:e};t?Z(t)(a):D(a)},F.dismissAll=e=>F.dismiss(void 0,e),F.remove=(e,t)=>{let a={type:4,toastId:e};t?Z(t)(a):D(a)},F.removeAll=e=>F.remove(void 0,e),F.promise=(e,t,a)=>{let s=F.loading(t.loading,{...a,...null==a?void 0:a.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let r=t.success?N(t.success,e):void 0;return r?F.success(r,{id:s,...a,...null==a?void 0:a.success}):F.dismiss(s),e}).catch(e=>{let r=t.error?N(t.error,e):void 0;r?F.error(r,{id:s,...a,...null==a?void 0:a.error}):F.dismiss(s)}),e};var L=1e3,H=(e,t="default")=>{let{toasts:a,pausedAt:s}=T(e,t),r=(0,o.useRef)(new Map).current,i=(0,o.useCallback)((e,t=L)=>{if(r.has(e))return;let a=setTimeout(()=>{r.delete(e),n({type:4,toastId:e})},t);r.set(e,a)},[]);(0,o.useEffect)(()=>{if(s)return;let e=Date.now(),r=a.map(a=>{if(a.duration===1/0)return;let s=(a.duration||0)+a.pauseDuration-(e-a.createdAt);if(s<0){a.visible&&F.dismiss(a.id);return}return setTimeout(()=>F.dismiss(a.id,t),s)});return()=>{r.forEach(e=>e&&clearTimeout(e))}},[a,s,t]);let n=(0,o.useCallback)(Z(t),[t]),l=(0,o.useCallback)(()=>{n({type:5,time:Date.now()})},[n]),c=(0,o.useCallback)((e,t)=>{n({type:1,toast:{id:e,height:t}})},[n]),d=(0,o.useCallback)(()=>{s&&n({type:6,time:Date.now()})},[s,n]),u=(0,o.useCallback)((e,t)=>{let{reverseOrder:s=!1,gutter:r=8,defaultPosition:i}=t||{},o=a.filter(t=>(t.position||i)===(e.position||i)&&t.height),n=o.findIndex(t=>t.id===e.id),l=o.filter((e,t)=>t<n&&e.visible).length;return o.filter(e=>e.visible).slice(...s?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+r,0)},[a]);return(0,o.useEffect)(()=>{a.forEach(e=>{if(e.dismissed)i(e.id,e.removeDelay);else{let t=r.get(e.id);t&&(clearTimeout(t),r.delete(e.id))}})},[a,i]),{toasts:a,handlers:{updateHeight:c,startPause:l,endPause:d,calculateOffset:u}}},q=w`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,U=w`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,J=w`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,B=j("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${q} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${U} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${J} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,V=w`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,Y=j("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${V} 1s linear infinite;
`,G=w`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,K=w`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,Q=j("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${G} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${K} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,W=j("div")`
  position: absolute;
`,X=j("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,ee=w`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,et=j("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${ee} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,ea=({toast:e})=>{let{icon:t,type:a,iconTheme:s}=e;return void 0!==t?"string"==typeof t?o.createElement(et,null,t):t:"blank"===a?null:o.createElement(X,null,o.createElement(Y,{...s}),"loading"!==a&&o.createElement(W,null,"error"===a?o.createElement(B,{...s}):o.createElement(Q,{...s})))},es=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,er=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,ei=j("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,eo=j("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,en=(e,t)=>{let a=e.includes("top")?1:-1,[s,r]=C()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[es(a),er(a)];return{animation:t?`${w(s)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${w(r)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},el=o.memo(({toast:e,position:t,style:a,children:s})=>{let r=e.height?en(e.position||t||"top-center",e.visible):{opacity:0},i=o.createElement(ea,{toast:e}),n=o.createElement(eo,{...e.ariaProps},N(e.message,e));return o.createElement(ei,{className:e.className,style:{...r,...a,...e.style}},"function"==typeof s?s({icon:i,message:n}):o.createElement(o.Fragment,null,i,n))});i=o.createElement,p.p=void 0,g=i,b=void 0,v=void 0;var ec=({id:e,className:t,style:a,onHeightUpdate:s,children:r})=>{let i=o.useCallback(t=>{if(t){let a=()=>{s(e,t.getBoundingClientRect().height)};a(),new MutationObserver(a).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,s]);return o.createElement("div",{ref:i,className:t,style:a},r)},ed=(e,t)=>{let a=e.includes("top"),s=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:C()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(a?1:-1)}px)`,...a?{top:0}:{bottom:0},...s}},eu=x`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ep=({reverseOrder:e,position:t="top-center",toastOptions:a,gutter:s,children:r,toasterId:i,containerStyle:n,containerClassName:l})=>{let{toasts:c,handlers:d}=H(a,i);return o.createElement("div",{"data-rht-toaster":i||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...n},className:l,onMouseEnter:d.startPause,onMouseLeave:d.endPause},c.map(a=>{let i=a.position||t,n=ed(i,d.calculateOffset(a,{reverseOrder:e,gutter:s,defaultPosition:t}));return o.createElement(ec,{id:a.id,key:a.id,onHeightUpdate:d.updateHeight,className:a.visible?eu:"",style:n},"custom"===a.type?N(a.message,a):r?r(a):o.createElement(el,{toast:a,position:i}))}))},em=F}},function(e){e.O(0,[4581,1396,1865,9727,2971,4938,1744],function(){return e(e.s=4586)}),_N_E=e.O()}]);