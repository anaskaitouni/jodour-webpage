"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[5324],{3905:function(e,t,r){r.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(2898).Z)("Pencil",[["path",{d:"M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z",key:"5qss01"}],["path",{d:"m15 5 4 4",key:"1mk7zo"}]])},9883:function(e,t,r){r.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(2898).Z)("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]])},1138:function(e,t,r){r.d(t,{Z:function(){return a}});/**
 * @license lucide-react v0.303.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r(2898).Z)("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]])},8222:function(e,t,r){var a=r(7541);let i=[{id:"seating",name:"Seating",slug:"seating"},{id:"objects",name:"Objects",slug:"objects"},{id:"lighting",name:"Lighting",slug:"lighting"}];function o(e){return Promise.resolve({data:e})}t.Z={get:e=>{if(e.startsWith("/products?featured")||e.startsWith("/products?"))return o({products:a.n6,pagination:{total:a.n6.length}});if(e.startsWith("/products/")){let t=e.replace("/products/","").split("?")[0],r=a.n6.find(e=>e.slug===t);return r?o(r):Promise.reject(Error("Not found"))}return"/categories"===e?o(i):"/collections"===e?o(a.jn):"/orders"===e||e.startsWith("/users/wishlist")||e.startsWith("/users/addresses")?o([]):o({})},post:(e,t)=>"/auth/login"===e?o({user:{id:"mock-user",name:"Guest User",email:(null==t?void 0:t.email)||"user@jodour.com",role:"USER"},accessToken:"mock-token"}):"/auth/register"===e?o({user:{id:"mock-user",name:(null==t?void 0:t.name)||"Guest User",email:(null==t?void 0:t.email)||"user@jodour.com",role:"USER"},accessToken:"mock-token"}):"/auth/logout"===e?o({}):"/auth/refresh"===e?Promise.reject(Error("No refresh")):"/messages"===e||"/newsletter"===e?o({success:!0}):"/users/addresses"===e?o({id:"mock-address"}):"/orders"===e?o({id:"mock-order",orderNumber:"JOD-"+Math.floor(9e4*Math.random()+1e4)}):e.startsWith("/payments/")?o({url:"/checkout/success"}):e.startsWith("/users/wishlist/")?o({added:!0}):o({}),put:(e,t)=>o({}),patch:(e,t)=>o({}),delete:e=>o({}),defaults:{headers:{common:{}}},interceptors:{request:{use:()=>{}},response:{use:()=>{}}}}},7541:function(e,t,r){r.d(t,{OX:function(){return n},jn:function(){return s},n6:function(){return o}});let a="/assets/products";function i(e,t,r){return Array.from({length:t},(t,i)=>({id:"".concat(e,"-").concat(i+1),url:"".concat(a,"/").concat(e,"-").concat(i+1,".png"),alt:0===i?r:"".concat(r," view ").concat(i+1)}))}let o=[{id:"cloud",title:"Cloud",slug:"cloud",price:1890,comparePrice:2200,limited:!0,stock:12,featured:!0,description:"An sculptural office chair blending organic copper forms with textured upholstery — where Moroccan craftsmanship meets contemporary workspace design.",story:"Inspired by desert clouds and the soft curves of Atlas landscapes, Cloud reimagines the executive chair as a collectible design object.",images:i("cloud",6,"Cloud chair"),category:{name:"Seating",slug:"seating"},collection:{name:"Cloud Collection",slug:"cloud"},materials:[{id:"m1",name:"Copper"},{id:"m2",name:"Wool upholstery"}],dimensions:{width:65,height:120,depth:70,weight:18,unit:"cm"},reviews:[],_count:{reviews:0},related:[]},{id:"chelal",title:"Chelal",slug:"chelal",price:450,limited:!0,stock:24,featured:!0,description:"A luxury electric kettle adorned with traditional Moroccan filigree patterns in gold and bronze — heritage reimagined for the modern kitchen.",story:"Chelal draws from the ornate metalwork of Moroccan tea culture, transforming an everyday ritual into a moment of design.",images:i("chelal",4,"Chelal kettle"),category:{name:"Objects",slug:"objects"},collection:{name:"Chelal Collection",slug:"chelal"},materials:[{id:"m3",name:"Matte ceramic"},{id:"m4",name:"Gold filigree"}],dimensions:{width:22,height:28,depth:22,weight:1.8,unit:"cm"},reviews:[],_count:{reviews:0},related:[]},{id:"manara",title:"Manara",slug:"manara",price:680,limited:!0,stock:18,featured:!0,description:"Hammered copper table lamps with patterned ceramic bases — light as sculpture, rooted in Moroccan decorative tradition.",story:"Manara, meaning lighthouse, guides the eye through concentric copper rings that diffuse warm, ambient light.",images:i("manara",5,"Manara lamp"),category:{name:"Lighting",slug:"lighting"},collection:{name:"Manara Collection",slug:"manara"},materials:[{id:"m5",name:"Hammered copper"},{id:"m6",name:"Ceramic"}],dimensions:{width:35,height:55,depth:35,weight:3.2,unit:"cm"},reviews:[],_count:{reviews:0},related:[]}],s=[{id:"cloud",name:"Cloud",slug:"cloud",description:"Sculptural seating — copper and wool in organic harmony.",image:"".concat(a,"/cloud-1.png"),featured:!0,_count:{products:1}},{id:"chelal",name:"Chelal",slug:"chelal",description:"Moroccan filigree meets modern kitchen ritual.",image:"".concat(a,"/chelal-1.png"),featured:!0,_count:{products:1}},{id:"manara",name:"Manara",slug:"manara",description:"Hammered copper lighting — light as collectible art.",image:"".concat(a,"/manara-1.png"),featured:!0,_count:{products:1}}];function n(e){let t=o.find(t=>t.slug===e);if(!t)return null;let r=o.filter(t=>t.slug!==e).map(e=>({id:e.id,title:e.title,price:e.price,slug:e.slug,images:e.images}));return{...t,related:r}}},5925:function(e,t,r){let a,i;r.r(t),r.d(t,{CheckmarkIcon:function(){return Y},ErrorIcon:function(){return G},LoaderIcon:function(){return B},ToastBar:function(){return el},ToastIcon:function(){return er},Toaster:function(){return em},default:function(){return ep},resolveValue:function(){return E},toast:function(){return Z},useToaster:function(){return U},useToasterStore:function(){return S}});var o,s=r(2265);let n={data:""},l=e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||n},c=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,d=/\/\*[^]*?\*\/|  +/g,u=/\n+/g,m=(e,t)=>{let r="",a="",i="";for(let o in e){let s=e[o];"@"==o[0]?"i"==o[1]?r=o+" "+s+";":a+="f"==o[1]?m(s,o):o+"{"+m(s,"k"==o[1]?"":t)+"}":"object"==typeof s?a+=m(s,t?t.replace(/([^,])+/g,e=>o.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):o):null!=s&&(o="-"==o[1]?o:o.replace(/[A-Z]/g,"-$&").toLowerCase(),i+=m.p?m.p(o,s):o+":"+s+";")}return r+(t&&i?t+"{"+i+"}":i)+a},p={},f=e=>{if("object"==typeof e){let t="";for(let r in e)t+=r+f(e[r]);return t}return e},g=(e,t,r,a,i)=>{var o;let s=f(e),n=p[s]||(p[s]=(e=>{let t=0,r=11;for(;t<e.length;)r=101*r+e.charCodeAt(t++)>>>0;return"go"+r})(s));if(!p[n]){let t=s!==e?e:(e=>{let t,r,a=[{}];for(;t=c.exec(e.replace(d,""));)t[4]?a.shift():t[3]?(r=t[3].replace(u," ").trim(),a.unshift(a[0][r]=a[0][r]||{})):a[0][t[1]]=t[2].replace(u," ").trim();return a[0]})(e);p[n]=m(i?{["@keyframes "+n]:t}:t,r?"":"."+n)}let l=r&&p.g;return r&&(p.g=p[n]),o=p[n],l?t.data=t.data.replace(l,o):-1===t.data.indexOf(o)&&(t.data=a?o+t.data:t.data+o),n},h=(e,t,r)=>e.reduce((e,a,i)=>{let o=t[i];if(o&&o.call){let e=o(r),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;o=t?"."+t:e&&"object"==typeof e?e.props?"":m(e,""):!1===e?"":e}return e+a+(null==o?"":o)},"");function y(e){let t=this||{},r=e.call?e(t.p):e;return g(r.unshift?r.raw?h(r,[].slice.call(arguments,1),t.p):r.reduce((e,r)=>Object.assign(e,r&&r.call?r(t.p):r),{}):r,l(t.target),t.g,t.o,t.k)}y.bind({g:1});let b,v,w,x=y.bind({k:1});function k(e,t){let r=this||{};return function(){let a=arguments;function i(o,s){let n=Object.assign({},o),l=n.className||i.className;r.p=Object.assign({theme:v&&v()},n),r.o=/go\d/.test(l),n.className=y.apply(r,a)+(l?" "+l:""),t&&(n.ref=s);let c=e;return e[0]&&(c=n.as||e,delete n.as),w&&c[0]&&w(n),b(c,n)}return t?t(i):i}}var C=e=>"function"==typeof e,E=(e,t)=>C(e)?e(t):e,j=(a=0,()=>(++a).toString()),M=()=>{if(void 0===i&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");i=!e||e.matches}return i},$="default",O=(e,t)=>{let{toastLimit:r}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,r)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:a}=t;return O(e,{type:e.toasts.find(e=>e.id===a.id)?1:0,toast:a});case 3:let{toastId:i}=t;return{...e,toasts:e.toasts.map(e=>e.id===i||void 0===i?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let o=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+o}))}}},N=[],_={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},I={},A=(e,t=$)=>{I[t]=O(I[t]||_,e),N.forEach(([e,r])=>{e===t&&r(I[t])})},D=e=>Object.keys(I).forEach(t=>A(e,t)),P=e=>Object.keys(I).find(t=>I[t].toasts.some(t=>t.id===e)),T=(e=$)=>t=>{A(t,e)},z={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},S=(e={},t=$)=>{let[r,a]=(0,s.useState)(I[t]||_),i=(0,s.useRef)(I[t]);(0,s.useEffect)(()=>(i.current!==I[t]&&a(I[t]),N.push([t,a]),()=>{let e=N.findIndex(([e])=>e===t);e>-1&&N.splice(e,1)}),[t]);let o=r.toasts.map(t=>{var r,a,i;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(r=e[t.type])?void 0:r.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(a=e[t.type])?void 0:a.duration)||(null==e?void 0:e.duration)||z[t.type],style:{...e.style,...null==(i=e[t.type])?void 0:i.style,...t.style}}});return{...r,toasts:o}},L=(e,t="blank",r)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...r,id:(null==r?void 0:r.id)||j()}),H=e=>(t,r)=>{let a=L(t,e,r);return T(a.toasterId||P(a.id))({type:2,toast:a}),a.id},Z=(e,t)=>H("blank")(e,t);Z.error=H("error"),Z.success=H("success"),Z.loading=H("loading"),Z.custom=H("custom"),Z.dismiss=(e,t)=>{let r={type:3,toastId:e};t?T(t)(r):D(r)},Z.dismissAll=e=>Z.dismiss(void 0,e),Z.remove=(e,t)=>{let r={type:4,toastId:e};t?T(t)(r):D(r)},Z.removeAll=e=>Z.remove(void 0,e),Z.promise=(e,t,r)=>{let a=Z.loading(t.loading,{...r,...null==r?void 0:r.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let i=t.success?E(t.success,e):void 0;return i?Z.success(i,{id:a,...r,...null==r?void 0:r.success}):Z.dismiss(a),e}).catch(e=>{let i=t.error?E(t.error,e):void 0;i?Z.error(i,{id:a,...r,...null==r?void 0:r.error}):Z.dismiss(a)}),e};var W=1e3,U=(e,t="default")=>{let{toasts:r,pausedAt:a}=S(e,t),i=(0,s.useRef)(new Map).current,o=(0,s.useCallback)((e,t=W)=>{if(i.has(e))return;let r=setTimeout(()=>{i.delete(e),n({type:4,toastId:e})},t);i.set(e,r)},[]);(0,s.useEffect)(()=>{if(a)return;let e=Date.now(),i=r.map(r=>{if(r.duration===1/0)return;let a=(r.duration||0)+r.pauseDuration-(e-r.createdAt);if(a<0){r.visible&&Z.dismiss(r.id);return}return setTimeout(()=>Z.dismiss(r.id,t),a)});return()=>{i.forEach(e=>e&&clearTimeout(e))}},[r,a,t]);let n=(0,s.useCallback)(T(t),[t]),l=(0,s.useCallback)(()=>{n({type:5,time:Date.now()})},[n]),c=(0,s.useCallback)((e,t)=>{n({type:1,toast:{id:e,height:t}})},[n]),d=(0,s.useCallback)(()=>{a&&n({type:6,time:Date.now()})},[a,n]),u=(0,s.useCallback)((e,t)=>{let{reverseOrder:a=!1,gutter:i=8,defaultPosition:o}=t||{},s=r.filter(t=>(t.position||o)===(e.position||o)&&t.height),n=s.findIndex(t=>t.id===e.id),l=s.filter((e,t)=>t<n&&e.visible).length;return s.filter(e=>e.visible).slice(...a?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+i,0)},[r]);return(0,s.useEffect)(()=>{r.forEach(e=>{if(e.dismissed)o(e.id,e.removeDelay);else{let t=i.get(e.id);t&&(clearTimeout(t),i.delete(e.id))}})},[r,o]),{toasts:r,handlers:{updateHeight:c,startPause:l,endPause:d,calculateOffset:u}}},F=x`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,R=x`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,q=x`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,G=k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${F} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${R} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${q} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,V=x`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,B=k("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${V} 1s linear infinite;
`,J=x`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,X=x`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,Y=k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${J} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${X} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,K=k("div")`
  position: absolute;
`,Q=k("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,ee=x`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,et=k("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${ee} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,er=({toast:e})=>{let{icon:t,type:r,iconTheme:a}=e;return void 0!==t?"string"==typeof t?s.createElement(et,null,t):t:"blank"===r?null:s.createElement(Q,null,s.createElement(B,{...a}),"loading"!==r&&s.createElement(K,null,"error"===r?s.createElement(G,{...a}):s.createElement(Y,{...a})))},ea=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,ei=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,eo=k("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,es=k("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,en=(e,t)=>{let r=e.includes("top")?1:-1,[a,i]=M()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[ea(r),ei(r)];return{animation:t?`${x(a)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${x(i)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},el=s.memo(({toast:e,position:t,style:r,children:a})=>{let i=e.height?en(e.position||t||"top-center",e.visible):{opacity:0},o=s.createElement(er,{toast:e}),n=s.createElement(es,{...e.ariaProps},E(e.message,e));return s.createElement(eo,{className:e.className,style:{...i,...r,...e.style}},"function"==typeof a?a({icon:o,message:n}):s.createElement(s.Fragment,null,o,n))});o=s.createElement,m.p=void 0,b=o,v=void 0,w=void 0;var ec=({id:e,className:t,style:r,onHeightUpdate:a,children:i})=>{let o=s.useCallback(t=>{if(t){let r=()=>{a(e,t.getBoundingClientRect().height)};r(),new MutationObserver(r).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,a]);return s.createElement("div",{ref:o,className:t,style:r},i)},ed=(e,t)=>{let r=e.includes("top"),a=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:M()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(r?1:-1)}px)`,...r?{top:0}:{bottom:0},...a}},eu=y`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,em=({reverseOrder:e,position:t="top-center",toastOptions:r,gutter:a,children:i,toasterId:o,containerStyle:n,containerClassName:l})=>{let{toasts:c,handlers:d}=U(r,o);return s.createElement("div",{"data-rht-toaster":o||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...n},className:l,onMouseEnter:d.startPause,onMouseLeave:d.endPause},c.map(r=>{let o=r.position||t,n=ed(o,d.calculateOffset(r,{reverseOrder:e,gutter:a,defaultPosition:t}));return s.createElement(ec,{id:r.id,key:r.id,onHeightUpdate:d.updateHeight,className:r.visible?eu:"",style:n},"custom"===r.type?E(r.message,r):i?i(r):s.createElement(el,{toast:r,position:o}))}))},ep=Z}}]);